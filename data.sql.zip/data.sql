-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: datacenter
-- Waktu pembuatan: 04 Jun 2024 pada 13.27
-- Versi server: 10.11.5-MariaDB-1:10.11.5+maria~ubu2204
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esurvey`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `docs`
--

CREATE TABLE `docs` (
  `did` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `dnama` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `menuId` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `menuNama` varchar(100) NOT NULL,
  `menuRoute` varchar(100) DEFAULT NULL,
  `menuIcon` varchar(100) DEFAULT NULL,
  `menuParent` int(11) DEFAULT NULL,
  `menuOrder` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`menuId`, `compId`, `menuNama`, `menuRoute`, `menuIcon`, `menuParent`, `menuOrder`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dashboard', 'dashboard', 'icon-display4', NULL, 0, NULL, NULL),
(2, 1, 'Setup', '', 'icon-cog3', NULL, 2, NULL, NULL),
(3, 1, 'Company', 'company', '', 2, 1, NULL, NULL),
(4, 1, 'Menu', 'menu', '', 2, 2, NULL, NULL),
(5, 1, 'Role', 'role', '', 2, 3, NULL, NULL),
(6, 1, 'Role Menu', 'rolemenu', '', 2, 4, NULL, NULL),
(7, 1, 'User Super', 'user', '', 2, 5, NULL, NULL),
(8, 1, 'User Company', 'usercomp', '', 2, 6, NULL, NULL),
(9, 1, 'Ganti Password', 'gantipass', '', 2, 7, NULL, NULL),
(10, 1, 'Master', '', 'icon-database2', NULL, 3, NULL, NULL),
(12, 1, 'Pertanyaan', 'mspertanyaan', NULL, 10, 1, '2024-05-27 16:54:12', '2024-05-27 16:54:12'),
(13, 1, 'Pendidikan', 'mssekolah', NULL, 10, 2, '2024-05-30 08:29:29', '2024-05-30 08:29:29'),
(14, 1, 'Range Umur', 'msumur', NULL, 10, 4, '2024-05-30 08:38:30', '2024-05-30 08:38:30'),
(15, 1, 'Unit Kerja', 'msunit', NULL, 10, 5, '2024-06-04 19:02:59', '2024-06-04 19:02:59'),
(16, 1, 'Layanan', 'mslayanan', NULL, 10, 6, '2024-06-04 19:10:20', '2024-06-04 19:10:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_04_27_144928_create_docs_table', 1),
(6, '2022_05_12_113944_create_mscompany_table', 1),
(7, '2022_05_12_114103_create_menu_table', 1),
(8, '2022_05_12_114209_create_role_table', 1),
(9, '2022_05_12_114353_create_role_menu_table', 1),
(10, '2022_05_12_114533_create_syslog_table', 1),
(11, '2022_05_30_095845_create_mskel_table', 1),
(12, '2022_05_30_100143_create_mskec_table', 1),
(13, '2022_05_30_100330_create_mskab_table', 1),
(14, '2022_05_30_100400_create_msprov_table', 1),
(15, '2022_05_30_101746_create_msagama_table', 1),
(16, '2022_05_30_112349_create_mspendidikan_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `msagama`
--

CREATE TABLE `msagama` (
  `agamaId` int(10) UNSIGNED NOT NULL,
  `agamaNama` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `msagama`
--

INSERT INTO `msagama` (`agamaId`, `agamaNama`, `created_at`, `updated_at`) VALUES
(1, 'Islam', NULL, NULL),
(2, 'Kristen', NULL, NULL),
(3, 'Katolik', NULL, NULL),
(4, 'Hindu', NULL, NULL),
(5, 'Budha', NULL, NULL),
(6, 'Kong Hu Chu', NULL, NULL),
(7, 'Aliran Kepercayaan Lain', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mscompany`
--

CREATE TABLE `mscompany` (
  `compId` int(10) UNSIGNED NOT NULL,
  `compLogo` longtext NOT NULL,
  `compNama` varchar(100) DEFAULT NULL,
  `compPemilik` varchar(100) DEFAULT NULL,
  `compDetail` varchar(100) DEFAULT NULL,
  `compLokasi` varchar(200) DEFAULT NULL,
  `compBpjsId` varchar(255) DEFAULT NULL,
  `compKategori` int(11) DEFAULT NULL,
  `compStatusMng` int(11) DEFAULT NULL,
  `compStatus` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `mscompany`
--

INSERT INTO `mscompany` (`compId`, `compLogo`, `compNama`, `compPemilik`, `compDetail`, `compLokasi`, `compBpjsId`, `compKategori`, `compStatusMng`, `compStatus`, `created_at`, `updated_at`) VALUES
(1, 'data:image/png;base64, /9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2ODApLCBxdWFsaXR5ID0gOTAK/9sAQwADAgIDAgIDAwMDBAMDBAUIBQUEBAUKBwcGCAwKDAwLCgsLDQ4SEA0OEQ4LCxAWEBETFBUVFQwPFxgWFBgSFBUU/9sAQwEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAjgCBAwERAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A+VP+HXH7Tv8A0TL/AMr+l/8AyTQAf8OuP2nf+iZf+V/S/wD5JoAP+HXH7Tv/AETL/wAr+l//ACTQAf8ADrj9p3/omX/lf0v/AOSaAD/h1x+07/0TL/yv6X/8k0AH/Drj9p3/AKJl/wCV/S//AJJoAP8Ah1x+07/0TL/yv6X/APJNAB/w64/ad/6Jl/5X9L/+SaAD/h1x+07/ANEy/wDK/pf/AMk0AH/Drj9p3/omX/lf0v8A+SaAD/h1x+07/wBEy/8AK/pf/wAk0AH/AA64/ad/6Jl/5X9L/wDkmgA/4dcftO/9Ey/8r+l//JNAB/w64/ad/wCiZf8Alf0v/wCSaAD/AIdcftO/9Ey/8r+l/wDyTQAf8OuP2nf+iZf+V/S//kmgA/4dcftO/wDRMv8Ayv6X/wDJNAH7/UAFABQAUAFABQAUAQX19baXZXF5eXEVpZ28bTTXE7hI4kUZZmY8AAAkk8ACgNiDRdc03xJpkOo6RqFrqmnzbvKu7KZZopMMVO11JBwQQcHqCKbVtxJpq6L1IYUAFABQAUAFABQAUAFABQAUAFABQAUAct8UPH9n8Lfh/rnim+TzYdNtzIsOWHnSkhYoshWK75GRd2CBuyeAaqK5nYmUuWLbPzD8Zav8Tf2gfFkd7qlrqepzXM5+yWwjeOysw5VdsYY7IkwqAsSM7dzsTlqwqZrluF0q4iEfWUV+bOVYbFV3eNOT9EzKng8ffs7+N4v3t94U19Io50e3nVknhYh1+ZC0c0RZBkZZCUIIyCB6VOpTxFNVKbUovVNapp7NM5pRqUJuMlZo/S/9nj4xR/HD4Y2PiJoYrXUkkez1G2g3+XFcJgnaWHRlZHABbaH2liVJrlnHldj0Kc+eNz0uoNQoAKACgAoAKACgAoAKACgAoAKACgDzr47Q3lt4A1TW7XyphotncX8lpM5RJhHGX6gH5gFIHH8R5FfD8T8O1+Ifq9OnW5Ixk+Za6p9V0clqlfpJ6rZ+xl+YQy9VJyhzNrT5dPR/otD4i8CftXTXviR4/FUNrp+kSRkRyWcEjNHJkY3fMSVxkcDOce9fH5x4bwpYNSyqUp1U9VJpJrrbRa3tu9r+R24LiaU61sWlGHkno/PV/kcj+0X8YtJ+J76FY6LHdG00l7p2ublVRZXlMa/IvLbdsKHcxBO/GxduW+84MyHE5Dl7p4qd5zfM4q1ou1rX6vRX1tpaPVy8HO8wpZhXUqS0jpfv8ui7de/ZfY/7CPg7UvCfwJjn1KLyP7a1CXU7aJlZXEDRxxoWDAfe8oupGQUdCDzgfZVWnI4KCahqfRNYnQFABQAUAFABQAUAFABQAUAFABQAUAZPivVJNF8PXt5CMyogCHj5WYhQeQemc474r5ziPMKmVZVXxdL4oqy8nJqKeqa0bva2trHoYChHE4qFKWz3+Wtvnax+Y/7aPh7TPh7L4T1fSNMtrVtYe8hnSHKKTALcghAMDibqOuOa+b8OsZj8bga08XV54RklG+sk7Xld9Vqravrtoa8SUMPQrwVGPK2ru23Zfrcxv2J/AmiftAfF280LxLDcLpthpb6oIrSfyzMyXECeW5wTsZZWztKt6MK/VaknFXR8tRgpysz9YLGxttLsrezs7eK0s7eNYYbeBAkcSKMKqqOAAAAAOABXCepsT0AFABQAUAFABQAUAFABQAUAFAHL+PviToHw00tL3XbzyPN3C3t41LzTsq5Koo/AbjhQWXJGRVRi5OyM51I01eRyXgf9pTwZ461ePS4ZbvS72Z1jt49SiVBOxz8qsrMoPAGGIyWAGScVcqcoq5lDEQm7bHafECJ5vCGoqiM7AI2FGTgOpJ/AAn8K+F4zpzqZDiYwTbtF6a6KcW36JJt9lqfQ5RJRx1Nt23/Jn5zf8FEtUF3oHwutCV8y0k1YBQDnY32RgSenXd09BXmeG2YLE5XPCO3NSl5/DK8k30bvzLTolddWuJ6Dp4mNXpJfirL8rFD/AIJa/wDJwPiD/sWLj/0rtK/VK3wny+H+N+h+pNcZ6J5z8Rfj34T+Gl99g1G4nvdTG0vY2EYkkiVgSGcsVUdB8u7dhlOMHNaRpylqjnqV4U3Z7l/4cfGLwz8UY5F0a6kS9iTzJbC7Ty5413Fd2MlWHTlScblzgnFKUHHcqnVhU+E7eoNgoAKACgAoAKACgAoAKAPiX9o+7/tr483Vjql/9k062+yWgufJ3/ZoGjR3bauC+DJI2Opzj0rtp6Q0PHxDvVs3oY3xx8I+DPCer6ZH4O12PVoJrYfaYop1uBEy4UP5q/KS+GJT+EgnhWUBwcmveRFaEItcjufOt98aviE0lxAfH/ieWAlkw2s3BDL05G/nIpVKNKrB06kU4tWaaumnumuxrGrUi1KMmmvM9T8Ma7of7RvghPBfi+UR+IrU+ZY3r9ZWAIDj1bBIZf4hyOen4XmuW4rgvMf7ZyuHNh5aTj2T3Xkr6xfR6PTf7vCYmlneG+pYp2qLZ9/P17rrv6ePXXhrxP8AADxXcJYXN94b1KSIwi/0q5kg+0QlgSFkUglSVUkeoGRkV+vZTm+DzzDLE4SV11T3i+zX9J9D4/F4SvgKrp1VZ9+j9C5/wvL4j/8ARQPFP/g6uf8A4uvZ5Y9jj5592e6fBXS9A8Z+MbH/AITXXjBYyRG6mubycg3svDFJJmPy78sxcnJwQCGYEKbaj7qMqajOfvs3fCyWXgv9oXSLbwvq/wDaenRaxDaw32xT5kUjCORemG4d03gYONy4yKT96GpUbQrJQelz7urhPaCgAoAKACgAoAKACgAoA8q+M3wC0/4uXVjfjUZNI1S2TyDcCLzkkhyzBCm5cEMxIYHuQQeNusKjhoc1agqut7M818E/sbyQ31vc+KtYt54IpsyafpyuVnjAGAZW2lcnggLnA4YE5Gkq38pzwwmt5s9o/wCFHfDj/on/AIW/8Ett/wDEVhzS7ndyQ7I+Gv8Agpt4S0P4fTfDGbwto2n+Gppm1J5JNItY7VnZPshQsYwMldzYJ6ZOOtbQiqsZQqK6fR6nJW/duLho/IqfsvfGhvjdHN4W8YaPa65qekW32+O9urVJ45YldI8yIwIDhpEGcYbPPPX8D4pyCvwvUWb5LUlCDaUkr+6915ODataWl2lrex91lOYQzWP1PGxUpJaN9f8Ag+a/Q+1PCHw1+GvijTPOPw98KxXMR2TRjR7bAOOGHyZwe2fQjnGa/SOGeIlxBg/bP3akXaSv17rW/K+l+qau7XfiZjlywNbkteL1Tt+Hqv8AJ9ThfiL+yFZ6vqF1qHhK+ttFEgUppMsJW2V8/NsdcmNcchAhAPAwpAX7SNW2kj5+phVJtwdjoPg3+zTbfDbW4de1LU/7U1aKHbDHDGY4bd2UrIQc5k4JUEhRgklckbZnU5lZF0sOqb5m7s9trE7AoAKACgAoAKACgAoAKACgAoAKAPz4/wCCsv8AzSv/ALiv/tnXTR6nFieh53/wS6iSb4+eI45EWSN/C1yrIwyGBurTIIpYqnCrSdOok4vRp6pp7prsThZONTmi7NH3v4StpPDvxFl04L8jeZDmQgt5eN6nI4yQq/meK/nDhuhUyTiyeXpaPnjrq+W3PF6aXajG+nVqye36XmE44zK1Xe6s9O97P82eqV/Q58GFABQAUAFABQAUAFABQAUAFABQAUAFAH5f/wDBU3UbuX44+GbB7qZ7GDw7HPFbNITFHI9zcK7qvQMwjjBI5IRc/dFddH4Tz8R8SPNv2Btek0D9qXwo5vpLKyuIb6K7CSMqzRizmcI4H3xvSNgpz8yqQMgVz4/FUMDhp4nEyUYR1bf9bvZJat6LUeEpzrV406au2fpn4JNz4g8dS6ptYRoZJn3sW2hgVVAcds8dOFPpX85cJvEZ1xLPM7Pli5Sd23ZSTjGN7bq9knb3Yu21j9NzT2eEy5Ybq7JfKzbt+fmz1av6KPgQoAKACgAoAKACgAoAKAPnSw/bHsoNTuLTX/CV/pXkbkdYJ1mmWUNgoyOse3HzZ5yCMY9Oj2PZnAsWr2lGx694T+LHhDxxIsWi6/aXVw7tGls7GGdyq7jtjcK7ADnIGODzwaycJR3R1Rqwn8LOtqDUKAMLXPGmleH5HhuJme5UBjBCu5uffoOOcEjj6ivkc34qyvJpyo4ibdRJPlirvX7op21s2nbXqr+rhcsxOLSnTjaL6vb/AD8tEfmd/wAFKrhfEHxO8L+IYwYop9KbT1gblgIZnfeT/tfaAMdtvU5rbhfiWHESr+zpOCptWu7tp3tdW0emqu/U4c4y54B03KV3Jfdb89/I4v8AYKMd18f4NJ3ol1qum3NtbGQHb5ihZjkgHHyQvz+Helxlk2Jz3L4YXCtJqabbdlZKS6JvdroLI8ZTwWJdSrezi1p6r/I/Wzw34btfDNgIIBvkbBlnYYaRv6Adh2+uSdsiyLDZDhvYUNZP4pdZP9Eui6ebbb6sbjamOqc89ui7f11ZrV9GeeFAHOeLPiL4Z8DRs2u61aafIEWT7O77p2UttDLEuXYZzyAeh9DVKLlsjOVSMPiZ454l/bK0LT7rytE0O71iNXdXnuJRaowBAVk4diG5PzBSOOOTjZUX1ZySxcV8Kue76BqM+r6Fp19c2cmnXN1bRzy2cud8DMoJjbIBypODkDp0FYNWdjti7pNl+kUFABQAUAfC37TPhNPCvxa1JoVjS31RF1KNEdmILkiQtu6EyJI2BkAMMY6Dupu8TxsRHlqPzPH9S1a00iHzLudYVPQHq30HU1qcyVz6w/Yw12+8V6ZqWor4xGraXbRR2f8AYUkkjy2Tg/IxDgeWuwEL5eVbJGQY8Dkq2XQ9TDKWrb07HvnjTXH0DQJriF1S5YiOEsu4bj1/IBjzxx36V8TxVm88myueIoySqNqMbq+r/C6im1fS61vs/o8swqxeJjTmrxWr9P8Ah7LQ4rwR4IGvK2q6qzTW8hbZGXO6VskFmIOeufcn26/lXCfCazhPNM0blTk3ZXd5u7TlJp3te/W7er0+L6bNM0eEf1bDaSVru23ZJbbfJLz2+Av+CndnDpnxz8N2drGILVPDMDrEn3dxubkFvdiFUE9TtGelfv8AlmX4TLqPssJSUI+S3sravdvzd2fneOr1cRU5qsm35/p2OE/YC/5O28Cf9v8A/wCkFxXpVfgZyUf4iP2KrhPUCgDxL9q/VdR8N+AbbW7XxiPClrZzkTRiWSKS9dl/dxxtGC5cYb5MbSCWYgR5rala9mrnLiFLlvF2Ph7StfsdaUm0nDsBkxnhh+Fdp47TR3vwn8Jp44+I2gaLKsb29xchrhJHZA8KAySLleQSiMBjHJHI61E3yxbNKUeeaifojXnnvBQAUAFABQB4H+2F4TfVvA2na7EsjyaRclZQHUIsM2FLEHknesQGP7xyO43ouzscOLjeKl2PhX4yfDPxh4Yt9K8Q6zo8tt4e1ONBp16siSRyBoxIA2xjsYgkgPgkK2Adpx1KSbsjjUJRim1ucX4O8b6/8P8AW4tX8OatdaPqMeB51rIV3qGVtjjo6EqpKMCpwMg02k9GNScXdH2X8OP2tb345ND4e1rSYNM1W3je6M9i5+z3OGwAEbLRlVYcbmDfMflwBX4t4l4fEfUKNSnL90pe8ut2vde2y95PVbrR9PuuGsRCVecJL3mtPS+v6fcfU/gDxLoWs6RHY6RqunX11p8MSXttZXEcj20jA5EqqSUYsr8NgkhvQ19xw/TjSyfCKEbL2cXppq4pt+rbbfmeXjp8+Lq3d3zP89D83v8AgqV/ycD4f/7Fi3/9K7uvq6Pwng4j416Hn37AX/J23gT/ALf/AP0guKqr8DIo/wARH66+IvFeieD7JLzXtYsNEs3kEKXGo3SW8bOQSFDOQCcKxx1wD6VxJN7HptpbnzT8U/8AgoB4Q8PWRg8EW0virU5I8pczxyW1pASHA3BwJHKsEJQKoKtxICMVtGi3uc08RFfDqfEnxO+LPif4veIJdW8S6nLdsZHeCzV2FtZhtoKQxkkIMIgPdtoLFjknqjFRVkcMpubuzR+C/wAM/GHxH8TMvhLR5dUaxCyXjiRIo4o2O35ndlXJ+Yhc5O1iAdpwOSjuJQlU0ij7R/Yy8Ju11r/iaRZFjVF02Bg67HJIklBX72RiHB4HzHr2wrPZG+EjvM+pK5T0goAKACgAoAKAKOtaHpviTTJtN1fT7XVdOm2+baXsKzRSYYMNyMCDggEZHUA007bCaT0Z8SfHD9gK9tbhtT+GUn221bc0uh6hcqsqMZOBBIwCsgVukjBgI87nLYHTGr0kcU8O94HzjpkHiP4B/E2wk1/R7zSr6zkJltbmMqZoSzRuyH7rqcOFdSVJGQTXk53lkM6y6rgm/iWj7Nap/fv5GmCxMsBiYVrbb+mzO9+P3w0GtbfH/hjGoaTfxia7EAyYzjHmY9Dj5u4IOevH5vwXn7wl8gzP3KtN2jfr/d9V9nurW8/pc7y/23/ChhfehLV2/P8Az7M8H1+4n8VPZvrNzcaq9lbJZWrXkzSGCBM7IkyflRcnCjgZOBX7Nax8U23uM8OSS+D9Yt9W0K4n0fVLfd5N7YzPDNHuUq211IIyrMDg8gkd6Gr7gm07oSmIvaLoWpeJdTh03SNPutV1Cbd5VpZQtNLJhSx2ooJOACTgdATSbtuNJvRH1J8IP2AvE2u6n9o+IMn/AAjekR71NnZXMUt7M20bCrKHjRMsckkt8hG0bgwwlVS+E6oYdv4tD7o8HeCNA+H+iRaR4c0m10fTo8HybWMLvYKq73PV3IVQXYljgZJrlbb1Z3KKirI3KRQUAFABQAUAFABQAUAFAFHWtD03xJpk2m6vp9rqunTbfNtL2FZopMMGG5GBBwQCMjqAaadthNJ6M8r1H9nnTvD7Xd14HVNJa5lEkujTzMNPYs7GR4xtZoWwwwE/d4RVCLncPieJOGMPxBFVL8laO0rbrs+/k90etl2YTy9uKV4Pp+qPlDxh8MPh/wCMvEV/pckkngPxjbSGO5025VY/3nXOwnY4IIYNE2GBDDIINfHU8x4q4VXJi6X1igtpK7sv8S1X/byfkehPC5VmrvSl7Op22/DZ/Jnn2v8A7K/jLS3J0/7HrMP8JgmEb49w+B+RNfT4LxFybEK2I5qT81dffG7/AAR5VfhvG03+7tNeTt+f+Z7N8Bv2PvCm2O/+JWqpd3kmGi0S0mkigjUxncLibapLhm6RuFBj+9IGwPWp8bZFiKipUsSk31alFd95JJfN+W5j/YWNpx56lP7mn+TufZ3hHR/DOgWU1n4XsdJ02zMnnS2+kRRRR7yANzLGAMkKBk84Uele5hswwuOv9WrRqW35ZKVr7Xs3a+plPD1KFueDjfurG9XaZBQAUAFABQAUAFABQAUAFABQAUAFAHhf7U37Nsfx58P2U2kmw0/xbYSKIL+8V1WW3Od8DsgJAy29SVbBBA2+YxrWnPkeuxhVp+0Wm5jfsv8A7NWofDrwndP43ne91e8dGisItQkkgsodinZtGF83eXDFSy4Vdp65+ezPIcqzaSliaCbXVXi36uLTfzO/B4vF4OLUKjXluvuZ6x/wqbSP+fm9/wC+0/8AiK+G/wCIcZT/AM/an3x/+QPe/wBYMV/LH7n/AJl/wl4Hg8LSTT/aGurmQbBJt2BU4OMZPcdfYdOc+zw3wlQ4enOt7R1Kkla9uVKOjta71bWrb6JK2t+TMM0nj0ocvLFa2319f6/y6avvDxAoAKACgAoAKAPKv+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoAP+Gsfgh/0WT4f/APhUWP8A8doAP+Gsfgh/0WT4f/8AhUWP/wAdoA/msoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKAP//Z', 'E-Survey', 'Kucip', 'E-Survey Bakamla Kupang', NULL, NULL, NULL, NULL, 1, NULL, '2024-05-27 15:49:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mslayanan`
--

CREATE TABLE `mslayanan` (
  `layId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `layNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mslayanan`
--

INSERT INTO `mslayanan` (`layId`, `compId`, `layNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'Layanan 1', '2024-06-04 19:10:58', '2024-06-04 19:10:58'),
(2, 1, 'Layanan 2', '2024-06-04 19:11:46', '2024-06-04 19:11:46'),
(3, 1, 'Layanan 3', '2024-06-04 19:11:52', '2024-06-04 19:11:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mssekolah`
--

CREATE TABLE `mssekolah` (
  `sekId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `sekLevel` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mssekolah`
--

INSERT INTO `mssekolah` (`sekId`, `compId`, `sekLevel`, `created_at`, `updated_at`) VALUES
(1, 1, 'SD/MI', '2024-05-30 08:31:04', '2024-05-30 08:45:48'),
(2, 1, 'SMP/MTS', '2024-05-30 08:31:09', '2024-05-30 08:45:57'),
(3, 1, 'SMA/SMK/MA', '2024-05-30 08:31:14', '2024-05-30 08:46:09'),
(4, 1, 'DIPLOMA (D1,D2,D3,D4)', '2024-05-30 08:31:28', '2024-05-30 08:46:34'),
(5, 1, 'S1 (Sarjana)', '2024-05-30 08:31:44', '2024-05-30 08:31:44'),
(6, 1, 'S2 (Magister)', '2024-05-30 08:31:53', '2024-05-30 08:31:53'),
(7, 1, 'S3 (Doktor)', '2024-05-30 08:32:04', '2024-05-30 08:32:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mssurvey`
--

CREATE TABLE `mssurvey` (
  `surId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `surPertanyaan` text NOT NULL,
  `surOpt1` text NOT NULL,
  `surOpt2` text NOT NULL,
  `surOpt3` text NOT NULL,
  `surOpt4` text NOT NULL,
  `surOpt5` text NOT NULL,
  `surBobot1` int(11) NOT NULL DEFAULT 1,
  `surBobot2` int(11) NOT NULL DEFAULT 1,
  `surBobot3` int(11) NOT NULL DEFAULT 1,
  `surBobot4` int(11) NOT NULL DEFAULT 1,
  `surBobot5` int(11) NOT NULL DEFAULT 1,
  `surTayang` int(10) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mssurvey`
--

INSERT INTO `mssurvey` (`surId`, `compId`, `surPertanyaan`, `surOpt1`, `surOpt2`, `surOpt3`, `surOpt4`, `surOpt5`, `surBobot1`, `surBobot2`, `surBobot3`, `surBobot4`, `surBobot5`, `surTayang`, `created_at`, `updated_at`) VALUES
(2, 1, 'Berapa tahun Anda telah bekerja sebagai nelayan?', 'Kurang dari 1 tahun', '1-5 tahun', '6-10 tahun', '11-20 tahun', 'Lebih dari 20 tahun', 1, 1, 1, 1, 1, 1, '2024-05-28 10:21:07', '2024-05-28 10:21:07'),
(3, 1, 'Seberapa sering Anda melaut dalam satu minggu?', '1-2 kali', '3-4 kali', '5-6 kali', 'Setiap hari', 'Tidak menentu', 1, 1, 1, 1, 1, 1, '2024-05-28 10:22:30', '2024-05-28 10:22:30'),
(4, 1, 'Jenis kapal apa yang Anda gunakan untuk melaut?', 'Perahu tradisional', 'Kapal dengan mesin kecil', 'Kapal dengan mesin sedang', 'Kapal besar dengan mesin besar', 'Kapal nelayan modern dengan teknologi canggih', 1, 1, 1, 1, 1, 1, '2024-05-28 10:30:14', '2024-05-28 10:30:14'),
(5, 1, 'Apa tantangan terbesar yang Anda hadapi saat melaut?', 'Cuaca buruk', 'Kurangnya ikan', 'Harga bahan bakar yang tinggi', 'Persaingan dengan nelayan lain', 'Regulasi pemerintah', 1, 1, 1, 1, 1, 1, '2024-05-28 10:31:18', '2024-05-28 10:31:18'),
(6, 1, 'Berapa banyak hasil tangkapan rata-rata Anda dalam sekali melaut?', 'Kurang dari 50 kg', '50-100 kg', '101-200 kg', '201-500 kg', 'Lebih dari 500 kg', 1, 1, 1, 1, 1, 1, '2024-05-28 10:32:13', '2024-05-28 10:32:13'),
(7, 1, 'Bagaimana Anda menjual hasil tangkapan Anda?', 'Langsung ke pasar ikan', 'Melalui pengepul', 'Ke pabrik pengolahan ikan', 'Langsung ke restoran/hotel', 'Dijual kepada konsumen langsung (online/offline)', 1, 1, 1, 1, 1, 1, '2024-05-28 10:32:59', '2024-05-28 10:32:59'),
(8, 1, 'Seberapa puas Anda dengan pendapatan dari melaut?', 'Sangat tidak puas', 'Tidak puas', 'Cukup puas', 'Puas', 'Sangat puas', 1, 1, 1, 1, 1, 1, '2024-05-28 10:33:58', '2024-05-28 10:33:58'),
(9, 1, 'Apakah Anda menggunakan alat bantu navigasi atau teknologi saat melaut?', 'Tidak pernah', 'Kadang-kadang', 'Sering', 'Selalu', 'Tidak perlu karena pengalaman', 1, 1, 1, 1, 1, 1, '2024-05-28 10:34:43', '2024-05-28 10:34:43'),
(10, 1, 'Bagaimana Anda menjaga keberlanjutan lingkungan laut?', 'Tidak melakukan apa-apa', 'Menggunakan alat tangkap ramah lingkungan', 'Menjaga kebersihan laut dengan tidak membuang sampah', 'Mengikuti program konservasi pemerintah', 'Mendukung kegiatan pelestarian laut lainnya', 1, 1, 1, 1, 1, 1, '2024-05-28 10:35:38', '2024-05-28 10:35:38'),
(11, 1, 'Apakah Anda pernah menerima bantuan atau pelatihan dari pemerintah atau organisasi lain?', 'Tidak pernah', 'Pernah sekali', 'Beberapa kali', 'Sering', 'Selalu menerima bantuan atau pelatihan', 1, 1, 1, 1, 1, 1, '2024-05-28 10:36:28', '2024-05-28 10:36:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msumur`
--

CREATE TABLE `msumur` (
  `umurId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `umurNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `msumur`
--

INSERT INTO `msumur` (`umurId`, `compId`, `umurNama`, `created_at`, `updated_at`) VALUES
(2, 1, '<= 10 Tahun', '2024-05-30 08:39:36', '2024-05-30 08:40:12'),
(3, 1, '11-15 Tahun', '2024-05-30 08:39:44', '2024-05-30 08:39:44'),
(4, 1, '16-20 Tahun', '2024-05-30 08:40:22', '2024-05-30 08:40:22'),
(5, 1, '21-25 Tahun', '2024-05-30 08:40:29', '2024-05-30 08:40:29'),
(6, 1, '26-30 Tahun', '2024-05-30 08:40:36', '2024-05-30 08:40:36'),
(7, 1, '31-35 Tahun', '2024-05-30 08:40:50', '2024-05-30 08:40:50'),
(8, 1, '36-40 Tahun', '2024-05-30 08:40:59', '2024-05-30 08:40:59'),
(9, 1, '41-45 Tahun', '2024-05-30 08:41:10', '2024-05-30 08:41:10'),
(10, 1, '46-50 Tahun', '2024-05-30 08:41:17', '2024-05-30 08:41:17'),
(11, 1, '51-55 Tahun', '2024-05-30 08:41:27', '2024-05-30 08:41:43'),
(12, 1, '56-60 Tahun', '2024-05-30 08:41:56', '2024-05-30 08:41:56'),
(13, 1, '61-65 Tahun', '2024-05-30 08:42:20', '2024-05-30 08:42:20'),
(14, 1, '66-70 Tahun', '2024-05-30 08:42:33', '2024-05-30 08:42:33'),
(15, 1, '>= 71 Tahun', '2024-05-30 08:42:42', '2024-05-30 08:42:42');

-- --------------------------------------------------------

--
-- Struktur dari tabel `msunit`
--

CREATE TABLE `msunit` (
  `unitId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `unitNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `msunit`
--

INSERT INTO `msunit` (`unitId`, `compId`, `unitNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'Unit 1', '2024-06-04 19:03:56', '2024-06-04 19:03:56'),
(2, 1, 'Unit 2', '2024-06-04 19:04:01', '2024-06-04 19:04:01'),
(3, 1, 'Unit 3', '2024-06-04 19:04:06', '2024-06-04 19:04:06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(75, 'App\\Models\\User', 1, 'auth_token', '0dfcb253df8661dd6a84f3445f073ce7bc2a5ac3bb50c5dca3be9ecea8b6ff47', '[\"*\"]', NULL, '2024-06-04 19:16:04', '2024-06-04 19:16:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `role`
--

CREATE TABLE `role` (
  `roleId` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `roleNama` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `role`
--

INSERT INTO `role` (`roleId`, `compId`, `roleNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'Administrator Utama', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `role_menu`
--

CREATE TABLE `role_menu` (
  `rmId` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `rmRoleId` int(11) NOT NULL,
  `rmMenuId` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `role_menu`
--

INSERT INTO `role_menu` (`rmId`, `compId`, `rmRoleId`, `rmMenuId`, `created_at`, `updated_at`) VALUES
(62, 1, 1, 1, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(63, 1, 1, 2, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(64, 1, 1, 3, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(65, 1, 1, 4, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(66, 1, 1, 5, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(67, 1, 1, 6, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(68, 1, 1, 7, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(69, 1, 1, 8, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(70, 1, 1, 9, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(71, 1, 1, 10, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(72, 1, 1, 12, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(73, 1, 1, 13, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(74, 1, 1, 14, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(75, 1, 1, 15, '2024-06-04 19:10:30', '2024-06-04 19:10:30'),
(76, 1, 1, 16, '2024-06-04 19:10:30', '2024-06-04 19:10:30');

-- --------------------------------------------------------

--
-- Struktur dari tabel `syslog`
--

CREATE TABLE `syslog` (
  `id` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `tabel` varchar(255) NOT NULL,
  `query` varchar(255) NOT NULL,
  `detail` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `syslog`
--

INSERT INTO `syslog` (`id`, `compId`, `user`, `tabel`, `query`, `detail`, `created_at`, `updated_at`) VALUES
(1, 1, 'Wahyu Budiman', 'menu', 'delete', '{\"menuId\":11,\"compId\":1,\"menuNama\":\"Docs\",\"menuRoute\":\"docs\",\"menuIcon\":\"\",\"menuParent\":10,\"menuOrder\":1,\"created_at\":null,\"updated_at\":null}', '2024-05-27 16:52:36', '2024-05-27 16:52:36'),
(2, 1, 'Wahyu Budiman', 'menu', 'create', '{\"compId\":\"1\",\"menuNama\":\"Pertanyaan\",\"menuRoute\":\"mspertanyaan\",\"menuIcon\":null,\"menuOrder\":\"1\",\"menuParent\":\"10\",\"updated_at\":\"2024-05-27T09:54:12.000000Z\",\"created_at\":\"2024-05-27T09:54:12.000000Z\",\"menuId\":12}', '2024-05-27 16:54:12', '2024-05-27 16:54:12'),
(3, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Test\",\"updated_at\":\"2024-05-27T11:07:01.000000Z\",\"created_at\":\"2024-05-27T11:07:01.000000Z\",\"surId\":1}', '2024-05-27 18:07:01', '2024-05-27 18:07:01'),
(4, 1, 'Wahyu Budiman', 'mssurvey', 'delete', '{\"surId\":1,\"compId\":1,\"surPertanyaan\":\"Test\",\"surOpt1\":\"\",\"surOpt2\":\"\",\"surOpt3\":\"\",\"surOpt4\":\"\",\"surOpt5\":\"\",\"surBobot1\":0,\"surBobot2\":0,\"surBobot3\":0,\"surBobot4\":0,\"surBobot5\":0,\"surTayang\":1,\"created_at\":\"2024-05-27T11:07:01.000000Z\",\"updated_at\":\"2024-05-27T11:07:01.000000Z\"}', '2024-05-28 10:20:15', '2024-05-28 10:20:15'),
(5, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Berapa tahun Anda telah bekerja sebagai nelayan?\",\"surOpt1\":\"Kurang dari 1 tahun\",\"surBobot1\":\"1\",\"surOpt2\":\"1-5 tahun\",\"surBobot2\":\"1\",\"surOpt3\":\"6-10 tahun\",\"surBobot3\":\"1\",\"surOpt4\":\"11-20 tahun\",\"surBobot4\":\"1\",\"surOpt5\":\"Lebih dari 20 tahun\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:21:07.000000Z\",\"created_at\":\"2024-05-28T03:21:07.000000Z\",\"surId\":2}', '2024-05-28 10:21:07', '2024-05-28 10:21:07'),
(6, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Seberapa sering Anda melaut dalam satu minggu?\",\"surOpt1\":\"1-2 kali\",\"surBobot1\":\"1\",\"surOpt2\":\"3-4 kali\",\"surBobot2\":\"1\",\"surOpt3\":\"5-6 kali\",\"surBobot3\":\"1\",\"surOpt4\":\"Setiap hari\",\"surBobot4\":\"1\",\"surOpt5\":\"Tidak menentu\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:22:30.000000Z\",\"created_at\":\"2024-05-28T03:22:30.000000Z\",\"surId\":3}', '2024-05-28 10:22:30', '2024-05-28 10:22:30'),
(7, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Jenis kapal apa yang Anda gunakan untuk melaut?\",\"surOpt1\":\"Perahu tradisional\",\"surBobot1\":\"1\",\"surOpt2\":\"Kapal dengan mesin kecil\",\"surBobot2\":\"1\",\"surOpt3\":\"Kapal dengan mesin sedang\",\"surBobot3\":\"1\",\"surOpt4\":\"Kapal besar dengan mesin besar\",\"surBobot4\":\"1\",\"surOpt5\":\"Kapal nelayan modern dengan teknologi canggih\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:30:14.000000Z\",\"created_at\":\"2024-05-28T03:30:14.000000Z\",\"surId\":4}', '2024-05-28 10:30:14', '2024-05-28 10:30:14'),
(8, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Apa tantangan terbesar yang Anda hadapi saat melaut?\",\"surOpt1\":\"Cuaca buruk\",\"surBobot1\":\"1\",\"surOpt2\":\"Kurangnya ikan\",\"surBobot2\":\"1\",\"surOpt3\":\"Harga bahan bakar yang tinggi\",\"surBobot3\":\"1\",\"surOpt4\":\"Persaingan dengan nelayan lain\",\"surBobot4\":\"1\",\"surOpt5\":\"Regulasi pemerintah\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:31:18.000000Z\",\"created_at\":\"2024-05-28T03:31:18.000000Z\",\"surId\":5}', '2024-05-28 10:31:18', '2024-05-28 10:31:18'),
(9, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Berapa banyak hasil tangkapan rata-rata Anda dalam sekali melaut?\",\"surOpt1\":\"Kurang dari 50 kg\",\"surBobot1\":\"1\",\"surOpt2\":\"50-100 kg\",\"surBobot2\":\"1\",\"surOpt3\":\"101-200 kg\",\"surBobot3\":\"1\",\"surOpt4\":\"201-500 kg\",\"surBobot4\":\"1\",\"surOpt5\":\"Lebih dari 500 kg\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:32:13.000000Z\",\"created_at\":\"2024-05-28T03:32:13.000000Z\",\"surId\":6}', '2024-05-28 10:32:13', '2024-05-28 10:32:13'),
(10, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Bagaimana Anda menjual hasil tangkapan Anda?\",\"surOpt1\":\"Langsung ke pasar ikan\",\"surBobot1\":\"1\",\"surOpt2\":\"Melalui pengepul\",\"surBobot2\":\"1\",\"surOpt3\":\"Ke pabrik pengolahan ikan\",\"surBobot3\":\"1\",\"surOpt4\":\"Langsung ke restoran\\/hotel\",\"surBobot4\":\"1\",\"surOpt5\":\"Dijual kepada konsumen langsung (online\\/offline)\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:32:59.000000Z\",\"created_at\":\"2024-05-28T03:32:59.000000Z\",\"surId\":7}', '2024-05-28 10:32:59', '2024-05-28 10:32:59'),
(11, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Seberapa puas Anda dengan pendapatan dari melaut?\",\"surOpt1\":\"Sangat tidak puas\",\"surBobot1\":\"1\",\"surOpt2\":\"Tidak puas\",\"surBobot2\":\"1\",\"surOpt3\":\"Cukup puas\",\"surBobot3\":\"1\",\"surOpt4\":\"Puas\",\"surBobot4\":\"1\",\"surOpt5\":\"Sangat puas\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:33:58.000000Z\",\"created_at\":\"2024-05-28T03:33:58.000000Z\",\"surId\":8}', '2024-05-28 10:33:58', '2024-05-28 10:33:58'),
(12, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Apakah Anda menggunakan alat bantu navigasi atau teknologi saat melaut?\",\"surOpt1\":\"Tidak pernah\",\"surBobot1\":\"1\",\"surOpt2\":\"Kadang-kadang\",\"surBobot2\":\"1\",\"surOpt3\":\"Sering\",\"surBobot3\":\"1\",\"surOpt4\":\"Selalu\",\"surBobot4\":\"1\",\"surOpt5\":\"Tidak perlu karena pengalaman\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:34:43.000000Z\",\"created_at\":\"2024-05-28T03:34:43.000000Z\",\"surId\":9}', '2024-05-28 10:34:43', '2024-05-28 10:34:43'),
(13, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Bagaimana Anda menjaga keberlanjutan lingkungan laut?\",\"surOpt1\":\"Tidak melakukan apa-apa\",\"surBobot1\":\"1\",\"surOpt2\":\"Menggunakan alat tangkap ramah lingkungan\",\"surBobot2\":\"1\",\"surOpt3\":\"Menjaga kebersihan laut dengan tidak membuang sampah\",\"surBobot3\":\"1\",\"surOpt4\":\"Mengikuti program konservasi pemerintah\",\"surBobot4\":\"1\",\"surOpt5\":\"Mendukung kegiatan pelestarian laut lainnya\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:35:38.000000Z\",\"created_at\":\"2024-05-28T03:35:38.000000Z\",\"surId\":10}', '2024-05-28 10:35:38', '2024-05-28 10:35:38'),
(14, 1, 'Wahyu Budiman', 'mssurvey', 'create', '{\"compId\":\"1\",\"surPertanyaan\":\"Apakah Anda pernah menerima bantuan atau pelatihan dari pemerintah atau organisasi lain?\",\"surOpt1\":\"Tidak pernah\",\"surBobot1\":\"1\",\"surOpt2\":\"Pernah sekali\",\"surBobot2\":\"1\",\"surOpt3\":\"Beberapa kali\",\"surBobot3\":\"1\",\"surOpt4\":\"Sering\",\"surBobot4\":\"1\",\"surOpt5\":\"Selalu menerima bantuan atau pelatihan\",\"surBobot5\":\"1\",\"updated_at\":\"2024-05-28T03:36:28.000000Z\",\"created_at\":\"2024-05-28T03:36:28.000000Z\",\"surId\":11}', '2024-05-28 10:36:28', '2024-05-28 10:36:28'),
(15, 1, 'Wahyu Budiman', 'menu', 'create', '{\"compId\":\"1\",\"menuNama\":\"Pendidikan\",\"menuRoute\":\"mssekolah\",\"menuIcon\":null,\"menuOrder\":\"2\",\"menuParent\":\"10\",\"updated_at\":\"2024-05-30T01:29:29.000000Z\",\"created_at\":\"2024-05-30T01:29:29.000000Z\",\"menuId\":13}', '2024-05-30 08:29:29', '2024-05-30 08:29:29'),
(16, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"SD\",\"updated_at\":\"2024-05-30T01:31:04.000000Z\",\"created_at\":\"2024-05-30T01:31:04.000000Z\",\"sekId\":1}', '2024-05-30 08:31:04', '2024-05-30 08:31:04'),
(17, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"SMP\",\"updated_at\":\"2024-05-30T01:31:09.000000Z\",\"created_at\":\"2024-05-30T01:31:09.000000Z\",\"sekId\":2}', '2024-05-30 08:31:09', '2024-05-30 08:31:09'),
(18, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"SMA\",\"updated_at\":\"2024-05-30T01:31:14.000000Z\",\"created_at\":\"2024-05-30T01:31:14.000000Z\",\"sekId\":3}', '2024-05-30 08:31:14', '2024-05-30 08:31:14'),
(19, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"DIPLOMA\",\"updated_at\":\"2024-05-30T01:31:28.000000Z\",\"created_at\":\"2024-05-30T01:31:28.000000Z\",\"sekId\":4}', '2024-05-30 08:31:28', '2024-05-30 08:31:28'),
(20, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"S1 (Sarjana)\",\"updated_at\":\"2024-05-30T01:31:44.000000Z\",\"created_at\":\"2024-05-30T01:31:44.000000Z\",\"sekId\":5}', '2024-05-30 08:31:44', '2024-05-30 08:31:44'),
(21, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"S2 (Magister)\",\"updated_at\":\"2024-05-30T01:31:53.000000Z\",\"created_at\":\"2024-05-30T01:31:53.000000Z\",\"sekId\":6}', '2024-05-30 08:31:53', '2024-05-30 08:31:53'),
(22, 1, 'Wahyu Budiman', 'mssekolah', 'create', '{\"compId\":\"1\",\"sekLevel\":\"S3 (Doktor)\",\"updated_at\":\"2024-05-30T01:32:04.000000Z\",\"created_at\":\"2024-05-30T01:32:04.000000Z\",\"sekId\":7}', '2024-05-30 08:32:04', '2024-05-30 08:32:04'),
(23, 1, 'Wahyu Budiman', 'menu', 'create', '{\"compId\":\"1\",\"menuNama\":\"Range Umur\",\"menuRoute\":\"msumur\",\"menuIcon\":null,\"menuOrder\":\"4\",\"menuParent\":\"10\",\"updated_at\":\"2024-05-30T01:38:30.000000Z\",\"created_at\":\"2024-05-30T01:38:30.000000Z\",\"menuId\":14}', '2024-05-30 08:38:30', '2024-05-30 08:38:30'),
(24, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"0-5 Tahun\",\"updated_at\":\"2024-05-30T01:39:29.000000Z\",\"created_at\":\"2024-05-30T01:39:29.000000Z\",\"umurId\":1}', '2024-05-30 08:39:29', '2024-05-30 08:39:29'),
(25, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"6-10 Tahun\",\"updated_at\":\"2024-05-30T01:39:36.000000Z\",\"created_at\":\"2024-05-30T01:39:36.000000Z\",\"umurId\":2}', '2024-05-30 08:39:36', '2024-05-30 08:39:36'),
(26, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"11-15 Tahun\",\"updated_at\":\"2024-05-30T01:39:44.000000Z\",\"created_at\":\"2024-05-30T01:39:44.000000Z\",\"umurId\":3}', '2024-05-30 08:39:44', '2024-05-30 08:39:44'),
(27, 1, 'Wahyu Budiman', 'msumur', 'delete', '{\"umurId\":1,\"compId\":1,\"umurNama\":\"0-5 Tahun\",\"created_at\":\"2024-05-30T01:39:29.000000Z\",\"updated_at\":\"2024-05-30T01:39:29.000000Z\"}', '2024-05-30 08:39:59', '2024-05-30 08:39:59'),
(28, 1, 'Wahyu Budiman', 'msumur', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"umurNama\":\"<= 10 Tahun\"}', '2024-05-30 08:40:12', '2024-05-30 08:40:12'),
(29, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"16-20 Tahun\",\"updated_at\":\"2024-05-30T01:40:22.000000Z\",\"created_at\":\"2024-05-30T01:40:22.000000Z\",\"umurId\":4}', '2024-05-30 08:40:22', '2024-05-30 08:40:22'),
(30, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"21-25 Tahun\",\"updated_at\":\"2024-05-30T01:40:29.000000Z\",\"created_at\":\"2024-05-30T01:40:29.000000Z\",\"umurId\":5}', '2024-05-30 08:40:29', '2024-05-30 08:40:29'),
(31, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"26-30 Tahun\",\"updated_at\":\"2024-05-30T01:40:36.000000Z\",\"created_at\":\"2024-05-30T01:40:36.000000Z\",\"umurId\":6}', '2024-05-30 08:40:36', '2024-05-30 08:40:36'),
(32, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"31-35 Tahun\",\"updated_at\":\"2024-05-30T01:40:50.000000Z\",\"created_at\":\"2024-05-30T01:40:50.000000Z\",\"umurId\":7}', '2024-05-30 08:40:50', '2024-05-30 08:40:50'),
(33, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"36-40 Tahun\",\"updated_at\":\"2024-05-30T01:40:59.000000Z\",\"created_at\":\"2024-05-30T01:40:59.000000Z\",\"umurId\":8}', '2024-05-30 08:40:59', '2024-05-30 08:40:59'),
(34, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"41-45 Tahun\",\"updated_at\":\"2024-05-30T01:41:10.000000Z\",\"created_at\":\"2024-05-30T01:41:10.000000Z\",\"umurId\":9}', '2024-05-30 08:41:10', '2024-05-30 08:41:10'),
(35, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"46-50 Tahun\",\"updated_at\":\"2024-05-30T01:41:17.000000Z\",\"created_at\":\"2024-05-30T01:41:17.000000Z\",\"umurId\":10}', '2024-05-30 08:41:17', '2024-05-30 08:41:17'),
(36, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"50-55 Tahun\",\"updated_at\":\"2024-05-30T01:41:27.000000Z\",\"created_at\":\"2024-05-30T01:41:27.000000Z\",\"umurId\":11}', '2024-05-30 08:41:27', '2024-05-30 08:41:27'),
(37, 1, 'Wahyu Budiman', 'msumur', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"umurNama\":\"51-55 Tahun\"}', '2024-05-30 08:41:43', '2024-05-30 08:41:43'),
(38, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"56-60 Tahun\",\"updated_at\":\"2024-05-30T01:41:56.000000Z\",\"created_at\":\"2024-05-30T01:41:56.000000Z\",\"umurId\":12}', '2024-05-30 08:41:56', '2024-05-30 08:41:56'),
(39, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"61-65 Tahun\",\"updated_at\":\"2024-05-30T01:42:20.000000Z\",\"created_at\":\"2024-05-30T01:42:20.000000Z\",\"umurId\":13}', '2024-05-30 08:42:20', '2024-05-30 08:42:20'),
(40, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\"66-70 Tahun\",\"updated_at\":\"2024-05-30T01:42:33.000000Z\",\"created_at\":\"2024-05-30T01:42:33.000000Z\",\"umurId\":14}', '2024-05-30 08:42:33', '2024-05-30 08:42:33'),
(41, 1, 'Wahyu Budiman', 'msumur', 'create', '{\"compId\":\"1\",\"umurNama\":\">= 71 Tahun\",\"updated_at\":\"2024-05-30T01:42:42.000000Z\",\"created_at\":\"2024-05-30T01:42:42.000000Z\",\"umurId\":15}', '2024-05-30 08:42:42', '2024-05-30 08:42:42'),
(42, 1, 'Wahyu Budiman', 'mssekolah', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"sekLevel\":\"SD\\/MI\"}', '2024-05-30 08:45:48', '2024-05-30 08:45:48'),
(43, 1, 'Wahyu Budiman', 'mssekolah', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"sekLevel\":\"SMP\\/MTS\"}', '2024-05-30 08:45:57', '2024-05-30 08:45:57'),
(44, 1, 'Wahyu Budiman', 'mssekolah', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"sekLevel\":\"SMA\\/SMK\\/MA\"}', '2024-05-30 08:46:09', '2024-05-30 08:46:09'),
(45, 1, 'Wahyu Budiman', 'mssekolah', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"sekLevel\":\"DIPLOMA (D1,D2,D3)\"}', '2024-05-30 08:46:21', '2024-05-30 08:46:21'),
(46, 1, 'Wahyu Budiman', 'mssekolah', 'update', '{\"_token\":\"bRkCHFqp6idZlg6oKAuajwR34rYdnKOggedXSYOv\",\"compId\":\"1\",\"sekLevel\":\"DIPLOMA (D1,D2,D3,D4)\"}', '2024-05-30 08:46:34', '2024-05-30 08:46:34'),
(47, 1, 'Wahyu Budiman', 'users', 'delete', '{\"id\":6,\"name\":\"Tony Stark\",\"username\":\"tonys\",\"email\":\"tonystark@gmail.com\",\"email_verified_at\":null,\"password\":\"$2y$10$q1g4AFgrBIFqC173.hTeKuq7m\\/9l\\/Js4XPy8yGWqGMegdO34gVLPq\",\"compId\":0,\"role\":0,\"created_at\":\"2023-07-07T23:37:37.000000Z\",\"updated_at\":\"2023-07-07T23:37:37.000000Z\"}', '2024-06-04 11:30:09', '2024-06-04 11:30:09'),
(48, 1, 'Wahyu Budiman', 'menu', 'create', '{\"compId\":\"1\",\"menuNama\":\"Unit Kerja\",\"menuRoute\":\"msunit\",\"menuIcon\":null,\"menuOrder\":\"5\",\"menuParent\":\"10\",\"updated_at\":\"2024-06-04T12:02:59.000000Z\",\"created_at\":\"2024-06-04T12:02:59.000000Z\",\"menuId\":15}', '2024-06-04 19:02:59', '2024-06-04 19:02:59'),
(49, 1, 'Wahyu Budiman', 'msunit', 'create', '{\"compId\":\"1\",\"unitNama\":\"Unit 1\",\"updated_at\":\"2024-06-04T12:03:56.000000Z\",\"created_at\":\"2024-06-04T12:03:56.000000Z\",\"unitId\":1}', '2024-06-04 19:03:56', '2024-06-04 19:03:56'),
(50, 1, 'Wahyu Budiman', 'msunit', 'create', '{\"compId\":\"1\",\"unitNama\":\"Unit 2\",\"updated_at\":\"2024-06-04T12:04:01.000000Z\",\"created_at\":\"2024-06-04T12:04:01.000000Z\",\"unitId\":2}', '2024-06-04 19:04:01', '2024-06-04 19:04:01'),
(51, 1, 'Wahyu Budiman', 'msunit', 'create', '{\"compId\":\"1\",\"unitNama\":\"Unit 3\",\"updated_at\":\"2024-06-04T12:04:06.000000Z\",\"created_at\":\"2024-06-04T12:04:06.000000Z\",\"unitId\":3}', '2024-06-04 19:04:06', '2024-06-04 19:04:06'),
(52, 1, 'Wahyu Budiman', 'menu', 'create', '{\"compId\":\"1\",\"menuNama\":\"Layanan\",\"menuRoute\":\"mslayanan\",\"menuIcon\":null,\"menuOrder\":\"6\",\"menuParent\":\"10\",\"updated_at\":\"2024-06-04T12:10:20.000000Z\",\"created_at\":\"2024-06-04T12:10:20.000000Z\",\"menuId\":16}', '2024-06-04 19:10:20', '2024-06-04 19:10:20'),
(53, 1, 'Wahyu Budiman', 'mslayanan', 'create', '{\"compId\":\"1\",\"layNama\":\"Layanan 1\",\"updated_at\":\"2024-06-04T12:10:58.000000Z\",\"created_at\":\"2024-06-04T12:10:58.000000Z\",\"layId\":0}', '2024-06-04 19:10:58', '2024-06-04 19:10:58'),
(54, 1, 'Wahyu Budiman', 'mslayanan', 'create', '{\"compId\":\"1\",\"layNama\":\"Layanan 2\",\"updated_at\":\"2024-06-04T12:11:46.000000Z\",\"created_at\":\"2024-06-04T12:11:46.000000Z\",\"layId\":2}', '2024-06-04 19:11:46', '2024-06-04 19:11:46'),
(55, 1, 'Wahyu Budiman', 'mslayanan', 'create', '{\"compId\":\"1\",\"layNama\":\"Layanan 3\",\"updated_at\":\"2024-06-04T12:11:52.000000Z\",\"created_at\":\"2024-06-04T12:11:52.000000Z\",\"layId\":3}', '2024-06-04 19:11:52', '2024-06-04 19:11:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `compId` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `compId`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Wahyu Budiman', 'kucip', 'admin@gmail.com', '2023-06-21 14:02:55', '$2y$10$/e4J53qtzUZS65pomQj5ROSbBePAX16cGDZ4US2qhAAowYQvtrzlW', '', 1, 1, NULL, '2023-06-24 12:54:10');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `docs`
--
ALTER TABLE `docs`
  ADD PRIMARY KEY (`did`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menuId`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `msagama`
--
ALTER TABLE `msagama`
  ADD PRIMARY KEY (`agamaId`);

--
-- Indeks untuk tabel `mscompany`
--
ALTER TABLE `mscompany`
  ADD PRIMARY KEY (`compId`);

--
-- Indeks untuk tabel `mslayanan`
--
ALTER TABLE `mslayanan`
  ADD PRIMARY KEY (`layId`);

--
-- Indeks untuk tabel `mssekolah`
--
ALTER TABLE `mssekolah`
  ADD PRIMARY KEY (`sekId`);

--
-- Indeks untuk tabel `mssurvey`
--
ALTER TABLE `mssurvey`
  ADD PRIMARY KEY (`surId`);

--
-- Indeks untuk tabel `msumur`
--
ALTER TABLE `msumur`
  ADD PRIMARY KEY (`umurId`);

--
-- Indeks untuk tabel `msunit`
--
ALTER TABLE `msunit`
  ADD PRIMARY KEY (`unitId`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleId`);

--
-- Indeks untuk tabel `role_menu`
--
ALTER TABLE `role_menu`
  ADD PRIMARY KEY (`rmId`);

--
-- Indeks untuk tabel `syslog`
--
ALTER TABLE `syslog`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `docs`
--
ALTER TABLE `docs`
  MODIFY `did` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `menu`
--
ALTER TABLE `menu`
  MODIFY `menuId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `msagama`
--
ALTER TABLE `msagama`
  MODIFY `agamaId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `mscompany`
--
ALTER TABLE `mscompany`
  MODIFY `compId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `mslayanan`
--
ALTER TABLE `mslayanan`
  MODIFY `layId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `mssekolah`
--
ALTER TABLE `mssekolah`
  MODIFY `sekId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `mssurvey`
--
ALTER TABLE `mssurvey`
  MODIFY `surId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `msumur`
--
ALTER TABLE `msumur`
  MODIFY `umurId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `msunit`
--
ALTER TABLE `msunit`
  MODIFY `unitId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT untuk tabel `role`
--
ALTER TABLE `role`
  MODIFY `roleId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `role_menu`
--
ALTER TABLE `role_menu`
  MODIFY `rmId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT untuk tabel `syslog`
--
ALTER TABLE `syslog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
