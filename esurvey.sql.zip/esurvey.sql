-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.56.20
-- Generation Time: Jul 12, 2024 at 03:10 PM
-- Server version: 10.3.39-MariaDB-0ubuntu0.20.04.2
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esurvey`
--

-- --------------------------------------------------------

--
-- Table structure for table `datasurvey`
--

CREATE TABLE `datasurvey` (
  `dataId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `dataNama` varchar(200) NOT NULL,
  `dataKelamin` int(11) NOT NULL,
  `dataHp` varchar(100) NOT NULL,
  `dataAlamat` varchar(200) NOT NULL,
  `dataUmur` int(11) NOT NULL,
  `dataPendidikan` int(11) NOT NULL,
  `dataPekerjaan` int(11) NOT NULL,
  `dataLayanan` int(11) NOT NULL,
  `dataUnit` int(11) NOT NULL,
  `dataTanya1` int(11) NOT NULL,
  `dataTanya2` int(11) NOT NULL,
  `dataTanya3` int(11) NOT NULL,
  `dataTanya4` int(11) NOT NULL,
  `dataTanya5` int(11) NOT NULL,
  `dataTanya6` int(11) NOT NULL,
  `dataTanya7` int(11) NOT NULL,
  `dataTanya8` int(11) NOT NULL,
  `dataTanya9` int(11) NOT NULL,
  `dataTanya10` int(11) NOT NULL,
  `dataJawab1` int(11) NOT NULL,
  `dataJawab2` int(11) NOT NULL,
  `dataJawab3` int(11) NOT NULL,
  `dataJawab4` int(11) NOT NULL,
  `dataJawab5` int(11) NOT NULL,
  `dataJawab6` int(11) NOT NULL,
  `dataJawab7` int(11) NOT NULL,
  `dataJawab8` int(11) NOT NULL,
  `dataJawab9` int(11) NOT NULL,
  `dataJawab10` int(11) NOT NULL,
  `dataSaran` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datasurvey`
--

INSERT INTO `datasurvey` (`dataId`, `compId`, `dataNama`, `dataKelamin`, `dataHp`, `dataAlamat`, `dataUmur`, `dataPendidikan`, `dataPekerjaan`, `dataLayanan`, `dataUnit`, `dataTanya1`, `dataTanya2`, `dataTanya3`, `dataTanya4`, `dataTanya5`, `dataTanya6`, `dataTanya7`, `dataTanya8`, `dataTanya9`, `dataTanya10`, `dataJawab1`, `dataJawab2`, `dataJawab3`, `dataJawab4`, `dataJawab5`, `dataJawab6`, `dataJawab7`, `dataJawab8`, `dataJawab9`, `dataJawab10`, `dataSaran`, `created_at`, `updated_at`) VALUES
(8, 1, 'Wahyu Budiman', 1, '085234729998', 'Manggis No. 10.A', 8, 3, 7, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 3, 4, 5, 2, 3, 2, 5, 4, 4, 0, 'test jhasb fjasbd jhjbjhasb jdbjhsabd jasbdjas jdbsj bdhmbjhb jsabdjsabd jhbdj dbsahbd jasbdjsa ds', '2024-06-14 11:01:14', '2024-06-14 11:01:14'),
(9, 1, 'Yeanry Olang', 2, '08113815327', 'Jln. M. Praja Km. 5 Alak', 8, 6, 2, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 'Sediakan air minum bagi korban', '2024-06-14 11:30:16', '2024-06-14 11:30:16'),
(12, 1, 'Achmad Romi', 1, '082238747785', 'Jl. M praja km 5 kel alak', 6, 3, 5, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 'Sangat membantu dan memberikan manfaat untuk masyarakat', '2024-06-14 15:34:34', '2024-06-14 15:34:34'),
(13, 1, 'Anita R.S. Simaremare', 2, '081360924998', 'Jl.M.Praja Km.5', 5, 4, 1, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 4, 5, 4, 4, 4, 5, 4, 4, 4, 0, 'Semoga Bakamla semakin Jaya', '2024-06-14 15:36:29', '2024-06-14 15:36:29'),
(19, 1, 'Agape Y. J. Selly', 1, '08113821656', 'Jl. Trikora no 42 Mantasi', 10, 6, 1, 2, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 'Sangat bagus', '2024-06-14 15:55:56', '2024-06-14 15:55:56'),
(20, 1, 'Kia', 1, '08113815327', 'Oebufu', 6, 3, 1, 2, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 4, 5, 3, 4, 5, 5, 4, 5, 4, 0, 'Terus Tingkatkan layanan', '2024-06-14 20:03:33', '2024-06-14 20:03:33'),
(21, 1, 'Key', 1, '0812345678', 'Oebufu', 7, 4, 1, 2, 2, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 2, 5, 4, 4, 4, 4, 4, 3, 3, 0, 'Coba', '2024-06-14 20:22:58', '2024-06-14 20:22:58'),
(22, 1, 'Dejavu', 1, '0812345678', 'Oebobo', 6, 5, 1, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 2, 5, 4, 4, 4, 4, 3, 4, 4, 0, 'Test survey', '2024-06-14 20:34:59', '2024-06-14 20:34:59'),
(23, 1, 'Deni Tampani', 1, '085792229265', 'Jl. Manutapen', 7, 2, 5, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 'Terimakasih sangat membantu dan bravo untuk bakamla', '2024-06-15 22:19:26', '2024-06-15 22:19:26'),
(25, 1, 'Abi', 1, '08113815327', 'Jl. M. Praja Km. 5 Alak Kupang', 7, 3, 5, 1, 2, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 4, 5, 4, 5, 3, 5, 4, 5, 5, 0, 'perbaiki tampilan grafik', '2024-07-01 13:33:20', '2024-07-01 13:33:20'),
(26, 1, 'budhi', 1, '081802949272', 'VBI 6 bogor', 7, 6, 1, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 4, 5, 5, 5, 5, 5, 0, 'semoga Bakamla makin Jaya', '2024-07-02 08:36:11', '2024-07-02 08:36:11'),
(27, 1, 'Dewi Setiyowati Gadi', 2, '082145083387', 'Jl. Jati RT 019 RW 005 Kel. Airnona', 7, 6, 7, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 4, 5, 5, 5, 5, 5, 0, 'Terus meningkatkan pelayanan publik terlebih untuk dunia pendidikan terkait magang/PKL atau penelitian', '2024-07-06 10:10:19', '2024-07-06 10:10:19'),
(28, 1, 'Yuda dt', 1, '081', 'kupang', 7, 5, 1, 1, 1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 'sudah bagus dan sangat membantu.', '2024-07-10 07:49:46', '2024-07-10 07:49:46');

-- --------------------------------------------------------

--
-- Table structure for table `docs`
--

CREATE TABLE `docs` (
  `did` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `dnama` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menuId` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `menuNama` varchar(100) NOT NULL,
  `menuRoute` varchar(100) DEFAULT NULL,
  `menuIcon` varchar(100) DEFAULT NULL,
  `menuParent` int(11) DEFAULT NULL,
  `menuOrder` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menuId`, `compId`, `menuNama`, `menuRoute`, `menuIcon`, `menuParent`, `menuOrder`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dashboard', 'dashboard', 'icon-display4', NULL, 0, NULL, NULL),
(2, 1, 'Setup', '', 'icon-cog3', NULL, 2, NULL, NULL),
(3, 1, 'Company', 'company', '', 2, 1, NULL, NULL),
(4, 1, 'Menu', 'menu', '', 2, 2, NULL, NULL),
(5, 1, 'Role', 'role', '', 2, 3, NULL, NULL),
(6, 1, 'Role Menu', 'rolemenu', '', 2, 4, NULL, NULL),
(7, 1, 'User Super', 'user', '', 2, 5, NULL, NULL),
(8, 1, 'User Company', 'usercomp', '', 2, 6, NULL, NULL),
(9, 1, 'Ganti Password', 'gantipass', '', 2, 7, NULL, NULL),
(10, 1, 'Master', '', 'icon-database2', NULL, 3, NULL, NULL),
(12, 1, 'Pertanyaan', 'mspertanyaan', NULL, 10, 1, '2024-05-27 16:54:12', '2024-05-27 16:54:12'),
(13, 1, 'Pendidikan', 'mssekolah', NULL, 10, 2, '2024-05-30 08:29:29', '2024-05-30 08:29:29'),
(14, 1, 'Range Umur', 'msumur', NULL, 10, 4, '2024-05-30 08:38:30', '2024-05-30 08:38:30'),
(15, 1, 'Unit Kerja', 'msunit', NULL, 10, 5, '2024-06-04 19:02:59', '2024-06-04 19:02:59'),
(16, 1, 'Layanan', 'mslayanan', NULL, 10, 6, '2024-06-04 19:10:20', '2024-06-04 19:10:20'),
(17, 1, 'Survey', NULL, 'icon-file-text', NULL, 5, '2024-06-11 15:20:51', '2024-06-11 15:21:34'),
(18, 1, 'Data Survey', 'rawdata', NULL, 17, 1, '2024-06-11 15:23:17', '2024-06-11 15:23:17'),
(19, 1, 'Analisa Data', NULL, 'icon-graph', NULL, 7, '2024-06-12 20:49:25', '2024-06-12 20:49:25'),
(20, 1, 'Grafik Keseluruhan', 'graph', NULL, 19, 1, '2024-06-12 20:49:59', '2024-06-12 20:49:59'),
(21, 1, 'Rangkuman Kritik & Saran', 'kritik', NULL, 19, 3, '2024-06-15 07:53:36', '2024-06-15 07:53:36'),
(22, 1, 'Hasil Survey', 'hasilsurvey', NULL, 19, 4, '2024-06-21 09:04:12', '2024-06-21 09:04:12'),
(23, 1, 'Pekerjaan', 'mskerja', NULL, 10, 8, '2024-06-21 18:58:32', '2024-06-21 18:58:32'),
(24, 1, 'Demografi Responden', 'demografi', NULL, 19, 6, '2024-06-21 20:13:56', '2024-06-21 20:13:56'),
(25, 1, 'Layanan Publik', 'layananpublik', NULL, 19, 10, '2024-06-28 07:51:41', '2024-06-28 07:51:41'),
(26, 1, 'IKM Per Unsur', 'ikmperunsur', NULL, 19, 9, '2024-06-28 12:48:02', '2024-06-28 12:53:15');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_04_27_144928_create_docs_table', 1),
(6, '2022_05_12_113944_create_mscompany_table', 1),
(7, '2022_05_12_114103_create_menu_table', 1),
(8, '2022_05_12_114209_create_role_table', 1),
(9, '2022_05_12_114353_create_role_menu_table', 1),
(10, '2022_05_12_114533_create_syslog_table', 1),
(11, '2022_05_30_095845_create_mskel_table', 1),
(12, '2022_05_30_100143_create_mskec_table', 1),
(13, '2022_05_30_100330_create_mskab_table', 1),
(14, '2022_05_30_100400_create_msprov_table', 1),
(15, '2022_05_30_101746_create_msagama_table', 1),
(16, '2022_05_30_112349_create_mspendidikan_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `msagama`
--

CREATE TABLE `msagama` (
  `agamaId` int(10) UNSIGNED NOT NULL,
  `agamaNama` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `msagama`
--

INSERT INTO `msagama` (`agamaId`, `agamaNama`, `created_at`, `updated_at`) VALUES
(1, 'Islam', NULL, NULL),
(2, 'Kristen', NULL, NULL),
(3, 'Katolik', NULL, NULL),
(4, 'Hindu', NULL, NULL),
(5, 'Budha', NULL, NULL),
(6, 'Kong Hu Chu', NULL, NULL),
(7, 'Aliran Kepercayaan Lain', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mscompany`
--

CREATE TABLE `mscompany` (
  `compId` int(10) UNSIGNED NOT NULL,
  `compLogo` longtext NOT NULL,
  `compNama` varchar(100) DEFAULT NULL,
  `compPemilik` varchar(100) DEFAULT NULL,
  `compDetail` varchar(100) DEFAULT NULL,
  `compLokasi` varchar(200) DEFAULT NULL,
  `compBpjsId` varchar(255) DEFAULT NULL,
  `compKategori` int(11) DEFAULT NULL,
  `compStatusMng` int(11) DEFAULT NULL,
  `compStatus` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mscompany`
--

INSERT INTO `mscompany` (`compId`, `compLogo`, `compNama`, `compPemilik`, `compDetail`, `compLokasi`, `compBpjsId`, `compKategori`, `compStatusMng`, `compStatus`, `created_at`, `updated_at`) VALUES
(1, 'data:image/png;base64, /9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2ODApLCBxdWFsaXR5ID0gOTAK/9sAQwADAgIDAgIDAwMDBAMDBAUIBQUEBAUKBwcGCAwKDAwLCgsLDQ4SEA0OEQ4LCxAWEBETFBUVFQwPFxgWFBgSFBUU/9sAQwEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAjgCBAwERAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A+VP+HXH7Tv8A0TL/AMr+l/8AyTQAf8OuP2nf+iZf+V/S/wD5JoAP+HXH7Tv/AETL/wAr+l//ACTQAf8ADrj9p3/omX/lf0v/AOSaAD/h1x+07/0TL/yv6X/8k0AH/Drj9p3/AKJl/wCV/S//AJJoAP8Ah1x+07/0TL/yv6X/APJNAB/w64/ad/6Jl/5X9L/+SaAD/h1x+07/ANEy/wDK/pf/AMk0AH/Drj9p3/omX/lf0v8A+SaAD/h1x+07/wBEy/8AK/pf/wAk0AH/AA64/ad/6Jl/5X9L/wDkmgA/4dcftO/9Ey/8r+l//JNAB/w64/ad/wCiZf8Alf0v/wCSaAD/AIdcftO/9Ey/8r+l/wDyTQAf8OuP2nf+iZf+V/S//kmgA/4dcftO/wDRMv8Ayv6X/wDJNAH7/UAFABQAUAcX8SvjF4Q+EmlTXniXW7WxlSEzxWAkVru5AOMRQ53PyQMgYHUkAEjOdSNOPNN2Q0nLRHhPib9rHxhqmqRR+E/CcGi6fGnmzv4pikkvWiKqRPHaQOGaJSSrMjSHkEhcHP51j+PMsw2mF/evZNNKHN/I5vSM+yly36M9CGCnL4tDy3VPjB4z8T2Ii1D4nalOYhEkj+GII44Y5OXEhktkZ5oJVGCyOskXBMeC2PF/1i4lzB3wOCtHXdNSa2t71lCpDe0k4T2U9r7+ww9P45f1/l+KOKuPinoEcHk3finV7hHnS7mt9Q8VmCeRncZjkL3CAyRsiyRS7QpCqsqowD1f1Xjqt9tR87QtdK8ZWs3yy+GpBu8X70JNe6Q6mCj/AF/Xyf3mPd+KPBeuW13DPrb6hLcW7xTA+I2mF4Y7kzgyIlw7Fbl2JdcM0coEihkywawnHFNp81129xtKWjWqV5Un70XtOGkrSsCq4N7f1/w/4Ho+kfE7xjogaHQfij4gszfXEkNo3imOO5Sd2j822Aa5jJVQQ1vKI2+8YpOFYZ55cRcT5XHnzHB80Uk5cqeii+WpZptaq1WF18PNHdXV+ww1X4Jf10/yZ6p4C/aq8V6ctpH4n0aLxbp8tvb/AGa/8OxLBf3HmQNJHLLbSyCNS5inQqj5EkRUL8yivawXHuX1Lwx8XRlHmUr+9FOMlGSUlq9JRneyXJK/RmM8FNaw1PePhx8ZfB/xXtTL4b1hLqdEEkllcRvb3UalVYMYZAr7SHXDgFTngmv0elWpV489GSkrtXTvqtGtOqejPPlFx0aO2rYkKACgAoAKACgAoAhvLyDT7Se6up47a1gRpZZpnCJGijLMzHgAAEkmgD5l+Lf7ReoeMLTV9E+HMskWkRFra98bWayXAikVsSw28cUbtnGR9pwUXkqGIBr4DiLi7C5JNYWFp13tFtRtfreTjF/4VJN+W530MLKquZ7Hyvf+PNF8E61Ha6RPcSeLtYuSseoSOs+o3c9xtaOSO53QGaFndCVu41jbkgttxXy+G4XzbiiSxOeT5aT+w00nbTWlLnUJW2nTqJ+WrZtUxVLC+7SV3/XX9Gjk9Q1rUrzxH8PtP8Wyv4X0PxNr09tJpoSN7iwiSUWks+xo/ssRMvnANHAH+SQljnn9Wy7hzLMsvPD0k5pW55e9Jrezk7yaWlrvTTseRUxVWq0pOy8ih4i+Htj4u/aF8FeE7m+s7uCx1R7XW4Bq17qktpBA2+cXFxPGkO4RRTALCoA8s5HSvpYvlg2crV5JHY6V/wAIP4R+Mlj8VdHn8KT6FNoeqG+0rS8fYLbVILRj5MUUqIdsqmJ0G3G5nVSdoqHzOPIx6J8yD4m/DfwR4h0bwp8OvDmu6JDpGi69dy6l4jhkiZksTbrdyzs45YIk/lqvQvFtHNEZSTcmgaTskVPE3w28NX/xa8Aaz4du7fwl8Pr/AEW9udaufCl62xLTT5ZvNJlXBaV4BbKxIyZJORzTUnytPV+fmFldNbGR4sl8Z/AzxHpWjiaXxBqGoa9dWmm6Va24iu5rSzvFW0nDoCsjSzrIQHiY/I3OJGFfO5jw9lWcwksVRV2nqtH70XGWq/u6fd2R008VWoNcr/pHb6Z4xsm8XHw/4jgl8P8AizR3srWQW0jWmoWCR3TSyFGjZtsa29zKA0cr/LArOFyBX5Rj+Fc44ecsdkVZzj+8k4vdt0kldbSbnCL2TvJ27nr08XRxH7usrPT8/wDJn0N8I/2pdX8MC1s/iHeQ6x4Zayhki8W2kB823dmuVC3SITvVvssmJo1AGF3jDF1+myTi7D5jU+qYqPsq15JJ7PlUH12f7yOj1vcxrYVwXNDVf8P/AJH1lbXMN7bRXFvKk8EqCSOWJgyupGQwI4II5zX6CcBLQAUAFABQAUAfGnxu+M1x8U5rm3sLm9tPhZAojlure01CNdfLqA2Z4rZmjgViUwD+8IJ5UrX5XxJxTKFdZRlElLES0dpUm4vsoTnFuX5eu3p4fD6e1qrT5/5Hztrmo+IPifeY0PQtQvfD+lXUen6lq+m6fb6xJoY2ureXtijln+QqeQVjwcbnAKe9wtwjRySn7fEvmrS1fxRjrrrBznDmT+0vl58mKxkqr5YbL+uyPlz4p+BPEfww8eXmmeIHkfUwwu4tRV2ZbyN/mS5jkPLK/UHrnIOCCB+oRkpK6PGkmnqfRsXjz4t/td3Z0rw14TfxLpc+m21vfHV4FFnp2oouJb22uAV8h3ILkBssWbKtgVhywpatmt5T2Pd4v2HPH/xIvLW0+Lvxjvbl7oyXjaNoMeLcP0Z8nYgc7m58nn5uTXnyx1GnWjh4r3mm16JpP80dCoTlBzk9F+p3Nj/wTL+CekwKLs69e8gebeamEJPp8iIP0rWWKktW0iVRiYPxC/YJ/Z28JeDr7X9RvNY0jTLXcGubTVBIxcEr5aB1YM+4EbcZyPY1lLH+zh7RyVj0cFlVfMcTHCYaDc5dP1fZeZ8I6v4M1DTtPv8A/hGNa1a08L3ck9jHbXs27fGWikaOQphctshYgLglB1214VPiWm6zpVKeq10ettVt/wAE/V63hntRw+LXtVFNqS0d9NGndK6/lfQ6dP2lvFmg6o+qeJvDun+INYk0+LQv7bmkmjmh05ImjaGB4nUwyMXZzKPmJJGMEg/Q4bE4bFq1Gfnbr9x+a5vw/mmRy/22l7v8y1j962+dn5Hpem+EPB/xf8d/EvxDpCr4p8ReJrLUH8IabbuVksI4EWOK8lHDRyGQRpGrbSArueNtdTlKKSeltz5yyk2znPBfxutPAXxKl8OXeuw+KY7a4hifW3HlW+oTIsgaMs77ERZbi4Kz4AkzmQDeZF/POKuDKGf4eVXD/u69nZrrfkvzW3doRV91b5HoYXHOjLlm7x/r/M+kf2f/AIy/8KQtrbTJZJb74cnZE8Sr+80R0t7D7RcjcQxhNxeOJY/vRsCyj7y189kHEteOJeV5unGpd2b6uVStyQf/AG5TTi+q87X769BSj7Slt/wFr97PuG0u4L+1hubaaO4tpkEkU0TBkdSMhlI4IIIIIr9TPLJaACgAoA+Zv2qfiPqup6p/wrTQ4ZRYXFiLvxHqUPlgwW7Sfu7dHa5hVWlEcgdWP+qfI68fE8U5/DJcJyxkva1NIp81/OXuwm9P8LV7I7cNRdWV3sv68j4U+L/xT0TQ9c0zSoNOit7ESx/bTpVpb2lzBZlisgV4jIvmSIMxsHYBGD8l1KPg3IKuEof2hjZylVqarmlOVk9dpxi031vFNbdzLHYlSfsobI6XxRo/gD9mnUbrUtC8UX0dnrtq0v8Awh93L9rj1jTWIa3uIruAKbZ2zviaRN6NGxJI+/8Ao6cqmjW3U8t2jseifs5/sfeKv2hU0Xx18b9Y1m/8P20IXRtE1K6eS6uLctuUyyHDLGc8AYZ+uVXGc51Y0/dplxg5ayP0I0Dw9pfhTR7XStG0+20rTLVBHBaWcSxRRr6KqgAVxNt6s6ErbHj3xm8R33hrx1bX9pKIZbWxR42bpy8g5HcHoa/IuKcdXwGbUq9B6xhpppq5XXzsv+HPq8soU8RhpU59Zfojzf4xftF+F9Q8GaXH4jvP7I1/z0ntbdGYQyDGHdxgkBckAAg5I5wWFZV84pcSZbVo1oONWDtZPRu2+v5P8U2e9lvDuYfWHPBU3UhbV2212/r87HjfxA8HeLfiBqkdjrN9Np/hHRo2NtCsfCTPmR12ZB3nJO5ui4+lcc8XiMky2jh61N3T5Yp263d3by/I+zyPPMuwNCpPDRUsTJ+9volZK7/RWvuZnxW8IadoHwl0zTtLt2LrqSKn8Us0pWRWJA+8Tjt6DHAFebleJq4vMFVnvKL2WiWjX4nrZBmFbF5vUr4iW8Xfskrfcl/w+p77+y/+xzYeGtLTxF4/0y31LWLuIiHR7yNZYbSNhg+YhyGkIPQ8Ln16fseAwPsbVanxdPL/AIJ8Txhxi8ycsvwD/c/al/P6f3fz9D57/bK/Z4039mzVT4q+FniOTw7c67bzWN34ZhkLS/Z5FxK0BwSIzgAqx4P3W/hH0X12lBxp13q9j80wmSY7MKdWvgqTlGmryt+nd9bLWx8pfC34VR+OLTVte1rV4fDvgzQjEdV1Rh5symQny4YYQd0krlWCjhRglmAFepKXLot2fPqN9z2D4OfGzRT4quNKMWotoMEitZR6i/2q8uLGKW3l8htuEMgW0jHC/NGDHk7IgfzLjTheWcYV4jBpLERTs9r3jOCu/wC6pycez9WetgcWqU+Sfw/1/kfb37LfxLl8IatD8OPEd/LPHdqo0C7lk8yIyw20H2uyjbPypE7YjGMYV1JLAbubhLP1nWGlTn/Ep6678jlJU2/70oxu/W/U6MVQ9lK62f59T6pr7w4QoAw/HPi208B+DNb8R32Da6XZy3bpuCl9ilggPqxAUepIpNpK7Dc/OD4p+KLjQ/D2q+I/FWmuPFWsMdTv1ntLXJDlQlmC7S3SIAVgTBhKqrMuSpB/F8pcuL+IJ4pT5sNSeiUqrTtttyUm2/eavU00elj16zWEw9re8/T/AIL/ACOM+GHxTh8RaLoVnovjTT/Bd/byPceK9F8XQI+n+IQ8he4uTJtIkIj+UW7qpVUAjYtkn97lC26v2t0PnE79T0L9jr9n22/aB+Id18Qdetpp/hl4Zu57HwrpGoLu8yIXEk0UTZ+/HD5vIJOWIXJCkVFWfIuVbvcqEeZ3ex+lIGBgcCuA6goA8W/aftNJ03wgPEepanDpiWhEL+byZ1Y8IgHLNnJwOxY9q+G4pyuWMpRxVFr2kL6PS6fT17dN7n1PD9PEYrE/VKEHJy106W6u+iX/AAD4e+Jvwy0r43eHZrnRtT1C9vNOB+zw2BSPzpMh/LR5VwGKgjnABZd3XFfJZBFYWpOhXioyqLS9t+l7a73V0/LsfY5njcwyOio8jhNNSum00tU7pOzWzs09r7Jp0fgr4lkjtL2DWdPnsbjVdQkmm1K7VpLy4laRjBDKYx5ZYRu2QiAbt33iaecVpZjFYelBSlFptx6u1m0t7X87+lzXDcKxyqjHEU1+/qJynG8dFdu7a67X+/ZH3l8I/gpDpZsta8Q2izX9s5msLaYZ+ykg/OQf48EgZ5UE9zx9Rw3kVTBXxeMVqjSSX8q/HV6baKx8Njs1m1Khh5WjLST7+Xp+Zd/aE/aF0b4E+G/Nl2X/AIhu0P2DTA3Lnp5j45WMHv36DuR9fi8XDCxu9W9kdPDnDmI4gxHLH3aUfil28l3b/wCCz8xfG3jbWfiJ4lvNe1+9e+1K6bLyN0UdlUdFUDgAdK+Kq1Z1puc3ds/qvAYDD5Zh44XCx5YR/q77t9WcO2o3HgHUbzVLSL7Toupwmx1rS8qEuYHIzjKsFYMFZXwSjqjAHFfZZPj/AG0fq1V+8tn+ny/I/AfEDhdYKf8Aa2Dj7kn76XRv7Xo+vZ+p6f4is/hT4Q+CGmeLtJ8Htp/iHxFbGPQLe61O7m1O1vI7hlku9wKRGBAibCIyXdyvyiNifpVzylyt6I/F3yqN0jvfhzrepeJPCtlPa2z6T4n0q4W6srYWiQm1vo5meO0SN8hWkursOxKgCARhum6vwHiKl/qtn9PNKOlKprLXTZKo3b7MKdNci/nnp2PosNL61QcJbr+l97Z+jvw28dWfxM8B6J4nsUaG31O2WYwuSWhfpJGTgZKOGUkDB25HFftEJKcVKOzPKas7HS1Qj59/bF1mSbwz4W8IwyMB4g1ZTdxCylulmtbdDM6GOIiQgyCAYUrkEgsqk18jxXj3l2T160XZtWT5oxtfS/NO8VpfVp+Sb0OvCw56qR8J/EGTx3f/ABBsJPhzobyan4ZuBrMkVpYW0ItjE7xQoYUJRm8xLplQNJIyygFmK4WuB8DHC5RCtVlzSq63cpybXT3ppPa20Yx7Lq8cfUc63LH7Jp/Hvx54/wDiXP4F+G8Euv8AhzW/FFw0eseF9cM0ksc80sXluksoJNngZRQ2U2TBs9T99TjGN5djz5Nu0T9NPhv4B0v4XeA9C8J6NH5enaTapbRnGC5A+Z2/2mYsx92NefKTk22dSVlZHSVIzlviT8StC+FHhS61/wAQXYtrSEbUjXmSeTHyxxr/ABMcfhyTgAmsK1aFCDnN6Hq5ZlmKzfExwuEjeT+5Lu30S/4C1Pzd8fftLaj8S/Hl1rHiTSLbVdAa3mtLfQpnKx2sbjh0kAysoIVjJjJIxgDAHyU8c6tVyqRvHa3/AAe/mf0rhOEqWW4CNHBVnTrJqTqW3a7q+sbXXLf9b9J8JrfRtS1yG+8Oald2WjWxJi0+eQq8dw7bt7SDAcBBtB7fJ3NfKYvDSUPbRqwjVbvZvl5Utkm99d3pfsfDcQYjE0oOjmNBSqTtapG0k4pW0W8bvXbX0Pb/AIP/AAzg0vxNJeeHoobrV7WVJEt5pFFpCgV1aRFK8Od0Y3jJH4mu/JcFX5faRqQlXi778ycWtU2ttdU03bt3+HzPOamKpqnVUuV3vLXmd7aNvdK2zPSvjd+0Jo3wI8Ji5NxBrXibU4/MsrKGTKScYEz4PEY9R94jAwB8v6Di8ZHDR/vdEc/DXDOIz/EWXu0o/FL9F5v8N30T/Njxl4z1j4geJL3XdevZL/Urt90kr9AOyqOiqBwAOAK+LqVJVZOc3ds/qvA4HD5bh44XCx5YR/q77t9WYlZHeRXVtHeW8kEq7o5FKsPY1pTqSpTVSD1RyYvC0sbQnhq6vCaaa8mavwZ8b6b4K8MeINFk8aQ/D3xXDeR/Z/Ek+mSX1wdO2yF7a1ZEZoHMjrJlSm7ccuMc/qVKqsTThWirprbz/rQ/ibM8BUynG1sDVfvQdr910fzVn8zp/hnrGnWniyTVdG1PxNrOi30kit4i1iCJ7+6vkULfC3RZGeJmtbpXBZmbMSnJxhfkOMsu/tHJ6sOVOULSSbtH3Xdc3eN1eS6pWMsDU9nWXZn3L+x/rsmnan428GzLawQ210uq2dtZwuIoFlyk8CSfcdIpYzHlcZYScdh4nBePeOyimpScnD3by+JreMpLpzpqST6Nb7nZjIclRvufS9feHCfGv7TOuQXfx5uonlikg0jw3DbvC7zlnlnmlldBbRYa6/dwwnYGWMDcZG+UCvyHxBqTlDC4anu5OV0o6Wsk+ed40/ifvWlK+kFc9XAq3NJ/18up8Y6N+0JZfCzx5q9lq3hODxClnq1ldLNaXz2Ulvd2UDQK0W1WTYGeZ1QpgFhwMCv2vD4b2WHp04vZJa6/e3q/XdngTqXqSbXU9i/YqbRfjD+1B4fv9IsdQt/DvgPwvJHZJq8yTzmVpnyXdVAYlruZgQB90dMVda8INPqwp2lLTofpnXnnUcV8YPipo/wd8Cal4i1a4jj8iJ/stux+e6n2kpGoHJJI5x0GSeBWNWrCjHmm7HpYDLsTmVV0cLByaTb8kt2/61ei1Pz2+LPjTVPip4u8Sad4htrm9h8PR3Eh19JrgizGD5czQhjAttK4QACMP5bq3mMVLHzq0PrVSVKcNF1Pt8txMuHcBRzLC4pc9R60rXuouzTfR+tt9DntJ+DHibwhZaD4x8R6N9n0mZ1uLW0u4RJ5jKQyrcRnorAZEbEbhnJTllwwWX+ytUq/F08v+CetxXxpLMebA5c7UtpS6y8l2j+fpo/r34deAfhf8NtbvvHvjA+H/C2u6qq3Eeh3l5GY9LBTL7UfB3sVdz8o2jIAGGJ9P6lSlUdVwu2fAVM/x88BDLZVH7OL+duivvZdF/kravxw+P8A4L0n4byzeFLyHxDJczxG5s9AZSz225XmWZ15hDRkjJwfnHYk06044WHNyaeS/EnKMrqZ1XdCFWMWk7c0krvpFLq3+B8e6r8PNd+Peq6t4r8GaPC0QjNxPptmoigjUcLHCOP3nytlMAsQzHYxKDgxeDji4+0p/F+Z9lw1xPX4brPA42L9ld3XWD6tfqvmtd+bstF07S9K0L7X4Uu9ZXVpmtZNQeS4glW5EpRre0VSqeYgKA+YsmZC4xhcVzLCwoxhCVPm5t32Z7dTiHFZpXxeJo4/2KpXdOFtJRXdvdvTR3d3tY47WtPTSdb1LT47lbyOzu5rZblPuzBJGQSD2YLuHsa8CvTVKrKC6M/acoxk8wy+ji6kbSnFNr+unbyKscbzSLHGrO7EKqqMkk9ABWG56zairvYt/GX4Y67+zp4l8G+I/Enh/S9Sl1uwmuE0jWIWliRl+QCZFZcuoeN9ucDgNnkV+j5RSqU8L7Opo7/cmfyJxxmODzLOJV8FrFJRb6SavqvK1lfrbsUdA/aB1nxpe6B4Y1TT9IstPbW7eS0Oj6dDYpYrJHLbzBY4VXfvWZTljuBiXB5r1KtCE4SjJXTTTT1ufBxqNSTPt/8AZp8UfZPjB4PfYLeDxFoNzYx24nMMQ8kRTIsNu3LRQhJYxIcM7yzN93FfhXAkp4bF47AzbbjJN3s3e7TlOS+3PR8i0hFRW9z6PGpShCf9fLyX4n2rX7EeSfDv7ULsnxG+JchS4tYf7Fs4ZJZbhbWCVTFLszOvzlSxKrbrgvIjFz5ZWvxvjBe0zzLqbV9br7T+JXcYP3Y2XxVZ/CvgXMevhNKM3/X9eR+bXxGne6+IXiieQlnk1W6dixySTMxOTX7/AB0ij5d6tn2//wAEkLOOTxH8TLoj99DaWESn0V3nLfrGtcmK2RvR6n3n8VfivoHwe8KT65r9z5ca5WC2Qgy3MmOERe59+gHJwK8evXhh4c82fSZTlGKzrErC4WN31fRLu/612R+Xnxo+NGufGjxXLrWty+Vbx5SzsI2JitY88KvqTxlurH2wB8XXr1MXUu/kj+qcoyjA8NYFwg0klec3pfzfZLounrdv279kvwpod6JNb8ba7P5uiRZ0/RNTuGW2t7fKHzCGbDBW8vEXAjJjfbl4yPrMHSq06dq0rv8AI/mzibH5djsZKeW0VCF3d63k+9r2S7WSfV9lzP7Uf7Wsni7VF8LaHM9roUsytbvFtEl2qOd13K7A+VChQsi7SX2M77Vwre7TopK73PiHPseIaVrFnZ6j8PvECwR6lBrN7Es1jfIZJFjOoyod8zsxZnS1AYqAfnPbaKt3alHsSrXi+5r+PNSs9U+JPxa1FrSCwtvD2oakfs1qhRpVW9jRFEiFSjGSeVw5DYOAuMAiY3UYruP7TfY7n9l/9p1fhj4kvdGmSa90adxPewEp5pV9givIcYEjFWTfHgNt2bdxQiplQil7qsazxFSrLmqycnpvq7LRfgeyftPaf4Y8QeGbTx34H8TS2ev3weH7Npdy0Yv48qJ94DAxSLhVZjgsdsbgkpjycRCc4NU5WZ9Dk+JwmDxcZ4+h7Wn1Wqt5qzSfo9GvvPji2heeVbeKJzNv8oQBDvD5xs29c54xXw1SnOE3Ca1P69weMwuLw0cThpp07aNbJL8rdV0P0C/ZO/ZJj8CRWvjDxlarL4kcCSz0+QZWwB6Ow7y/+g/Xp9NgMB7K1Wqve7dv+CfgPGHGLzFywGXytR2lL+fyX938/Tfyj/grfYpJofwzvCf3kVzfxAeoZYCf/QBX1eF3Z+M1uh+dOj3L2er2NxGcSRTo6keoYEV3s5j9JPhDHbp8TPhrOl6bdrTWHhWW0ja83k2s8SRSzMp25iZljiX/AFMTM8hDSDH8/wDDsfZ8U42FrK07X0+2r8seqb+OpL452UdIs+pxGuGi/T+n+iPvmv2M8g+If2ldFmj+NXjW2RoDd6toNpc2iwMpuSrR3MEgVXGyIEQHzbk5KxAIvzOMfjXHS9hjcHipfCnrp7vuyi1zNazab/d0lpKb5npFp+vgtYSj/X9d2fB2q+JtG8JfEPx0mo6MdTFxqF09t5gSPMbyMQrfKSAyN2PBAwM8j94cJTjFxdj51SjBtNHsf/BPz47aF8GfEvxFvNakdILzS457a0iQb7mWObCxrgAA4mPoAAT2rkzCtHD0VUn0PbyLKcRneMWEwq1erb2SW7f3lD4v/F/XvjR4tm1vW5sKMpaWUbHyrWLPCIP5t1J/AD85xGIniZ88/l5H9d5JkmFyLCrDYZa/al1k+7/RdCh8LtXv9B+IWhX2maLB4jvkuAkelXEAmW63gqUAIOGIY4YDKnBwRkHTB1nRrKUVe+n/AAxxcUZXSzXLKlKrV9mo+9e9o6fzd1+W6Pqz4l/BSf4ZfBXXNdl021bx3r8otNN09WM9roiyb2KRkg+ZIsfmjzCOrMF2h3LfYOv9XpuvVi2lq0tXb71e3W3yufylWpUqlVYfDTutuZ6XfprZdr69Xa9l8Q2HgnXde+JuqeHdC8NXOqeJpLRYrFr9i8k6M8cAdVDBApikZnLlwCHJK/MB7NDEUcTRjXpTTg9bo8erRqUZulONpLoe4fs+eCPFkaLb+MfDugaNofhjV7qG+1fVtMLSxvE0eILaJXWORi5lIKxt0Y5NcOPxWGwVKWIrVOWNu/8AX3bm+FoVsTNUqUbs4f4h+O9a+I/xD8b+DPB/hrw7ealrfiFNNhu7PTminuQ08kxWQPIYiRJCu52TBw7ZGc1204R5Y1G9NznnJ3cLHkmqXcfhrXtIHiDSVsbqzkm02+udOl2uWjkZJQQCUZPKkCgJtyMYbGK6E1JXi7ozs1pJHplhd39smjXtnIbu/kdtOu0h3bb2eFtgzGOVby3jXjDBvM2na3zfH5jVng8UpU9VLW3mfuHDGV4PibJJ0sW+WpQbSn1UbXXN3S10ey2aP0U+DnwHt5PENn8QvFXhvTtE11bSG303QrRQ8emRIvDSPtBlnOT8xHyDAHIJrujSVSSrVI2a2Xb+vwPgK+PlgcPUy3B1nKEn78ldKVtkl0j3e8uuiR75XYfNH5z/APBWDxLbDxJ8L9Hc7zapeX9xFgHKO8Kpwev+qkHNd2HTakc1V2aPjq81PQPGvjfwpZ6Rpv8AZiS3drbzZI2ncY0C5POE5XJJzjJ5yTtCMoJuTuRKUZtKKPub4MQf2v8AGP4P2d99qS8ie61JoZb/AMu6gH2KV/migwscbPIu7efMnyTIAoKH8G4R/wBoz7H4un8D5tUnyt8388tZtJWtFKnTWkbt3Po8T7tCMf6+7p+bPvqv2U8g+Wv2r/Dtxa/EXwprqr5+n6pp9xo1zDcELaeZG32mEXDE8Q7RcSOowXFuFO4EivzDj/C+0y2GLV06UlqtZJS933F/z8bahBv4XLm0auvSwMrTcO/9a+R+ZX7Qnhr/AIR7xyjxJOtpc2kXkNcwGF2SNfJRmT+FnjjjlK9vNHA6D9J4dxqx+V0K+l+Wzs7pSWkkn1Skmr9bXPGxcPZ1pI4jwpqI0zXrWVjiNm8tyemG4/Tg/hXfmdD6xhZwW61XyPpuEMyWV51QrTdot8svSWl/k7P5Htei6Lf+ItVtdM0y0lvtQupBFBbQKWeRj0AFfmEYynJRirtn9i169LC0pVq8lGMdW3sj7D0T4fWX7KHhq1ub0m7+IeqWc93NNZiN5bK1iTdJDa7/AJfMIyWlIIVEkPO1Vf7DBYJYZc0tZP8AA/mHiriurntT2FC8cPF6LrJ93+i/Xbm/2ttd0eLwJPpGma/MNc0jxNZ+KLYSXslxi3FrDBvedi3WZmAJbhsk4UEj2aNSHtfZPdpnwMsHiJ4WWMjH3IySb83e35fkZXwS+O+n6X8X7e6Wz0jRtdu7qaxv7S+iaNLSDzo/NnikI/dxSYDLyRklcMFBPyE8DicpzCeJotfV6lubXSL6t6/jt06K/srE0cwwkaNS/tYbea7f169z3fxD8DovGni2S6svGWky6Zc3ZuVsYr4yNEZiHkCDOPmJyD3yDivDxfDn9qYt1Hir0r35d7X1aTvpfe/nsejh85+o0FD2Fqlrc217aK+nQ0vBXwkj8P8AxU8SXFr4W0e0aC4ll0e7i06JY4ptiEGZ1j8xSyEAODjPmdTivp8PQr08TUU0uRfBskkrWXf06LXyv4larSnQhyv3vtd3fr29fkeX/G/4K+F/Bmn2tzr9loPmy2VzaW+kIwnnvzNCsTtBiAN9p+SM+aR/Cp3KFatHQxtCMFhJKKjdct9Gntd8t07639biVXDVXL28buWvNbVW30vZq2lvuOP+AXwi8H3stj43+0M1tqXiqQRyjUDHDA32O4lmMbowIIdIsOGJBAwehrHLK+NxkpvMoKM6cnFW9E+77qzPSxWIhgsL9Uy+o/ZVbSl3drq3pvdH1P8As/fGMeOZLnQ7uWeS7hthe2pvXRrn7OSBtkKfK+N8ZWUY3q+D88clfRJnzLVj2mmSfi/+3n8UI/ih+0r4jmtZhPpuihNFtWByCIc+aR2wZmlwe4xXrUI8sEcNR3kedfAvQJtd+IFs0KsfskTzbkiaVkdsRQsEUFnxLLESqgkgHAJrz83xkcBgK2Jk/hi3ul07yaS9W7dzTDw9pVjE/Tj9lrw1Dc/FfW7h7VrePwxpMNtbWsllDbxQS3ju8jRRozNE2y2Td5rNKwlG4gcH8h8PaHPhK2Pk1J1JJc15TbUV1m1FOzbS5IqCtZX1Pex0veUO3y/r56n1hX6weWeUftO+A5/Hnwi1Eafp6aprWjTQ63p1pIHYTy27b2h2ry/mxebDtOQfNx7jgzDBrMMJVwkpcvPFq63V1o15p6rzRpTnyTUj84P2kPBy+LvDNvrtiftLgPqP2r7PIJrhTkXFxL2XzTHM6LgbYrLjqAPzzw8zF0HWyauuWUH7sb6RslenHv7OLg5vrObv3fVmVLmSrL+vP56/IoT/AAZ+GafAu+1XTNQW8uHt76ePxPrF6thLLc2ojKR2dizbpbeYu8O45kEm0kIBg/s3PPnszxOVctz6i/4JlQeDdc8Ganqq/v8A4hWMptb9boDfbwH/AFbRDsrgHc3XcpHAxnxVgKeFqynBfF+Hkfa5nxTj86wtLC15WjTSTt9pr7Uu7/W7Pbfj/wCPfC58W+C/Amo32dQ1e9lgmt4TloYZrO5gVm5wpZ5UVcgk5PaplWpxqRpN6s4KOU4ytgauYxh+6hZN+baWne19ex8o3P7GfxN1HxzqIvJ9Mntb+WQ3euPMBFcxuTv3Qrh9zAnKYC54DY+avLp4KvTxKrKezv8A8A/RsRxdlNfJZZc8I1KUUrKyjdbSvvpurq/S/U+d/iH4A8TfC7xzd6Vced9mgT7Hf206CWK1dlZYLvDKVaJtqS+cBklXDbG+Wvr7xqR16/1Y/FtYvQyvh38R/ENjqVlbiSSxuodbtLSXyLu5gkxKzhwVSULgGMcYxlunNcksBhIXnClFNrdJJ6eaVzZYvEStGU212bbX3HoHxd/aV8b6JqPjDwxZzQGKLxPe6fZzlZJbhLeB2Tycs5G3548YXPB5xxWUMuozim2++/4ehpLGVIt2S+78fUwdGtviF8avHei6dqWqanqiwQrp+l27OVFzMmC7RgDb5cTs0hlIKKsag5JCt32hTV4qxzXlLRs/SPwR4Zu/h98OdG8CweBNP1Q6XHiz1GSaF7ASDIE0iv8Avlbk8KjkDjzD96vNdm20tzqV7K7On+Cfh1NDuPECQymeCyFnoyzbQPPaCAO8vHGS9w6kDoUIpIGc3+2L+0FD8A/hNd3FlKH8W6yGsNEtU5kMzDDTBepEYIbpyxRf4q3pQ55eRlOXKj80/AfwT+Hvi/4Q3/jDWPFWv6bqWjed/wAJCkNpb3H2SQyhbdRE8scjeduVQwJG9ZA2wAE+hKclLlSOVRTV2zqf2cfA9notvqetJJczWDNJdx3U9hdFxaIZEhkdLU5TcBOzxvKi7TCdzA1+ReIuaOnhqWW0vjqNXV6a2eivUvq3azjCctNEnZns5bR1dV9PX9P8z9Gv2UvCDeGfhHa389mNPvfEdzJrc9qkKQpEJQqwhYk4j/cRwZUliGLZJOa+xynBf2dgaWFbbcUrtycm3u/edm9fJabJLQyrT9pNyPYq9YxIL6xttUsrizvLeK7s7iNoZredA8cqMMMrKeCCCQQeCDSaTVmXCcqclODs1qmt0z4T+KHwih+G/j2TwVEEXw/rU/8AaXhpr2SSfy5CIo5onLY3Jax/a5QhY7knGTkMT+LcV4Wrw/jqfEGCi+WKtNLsryt61p+zg3uuXrc9qGIljnNV3eUm2/V76LRW1dlofNnhO20zwB4yjufEumxa6mnaWLzwbpviS4MWmw4cXdxaybv+WuyZ2i3naS8ZdTvUD9twOOpZnho4jDyundO3dNxa+TTT9D5qpTdGbjL5G3o3in4gy+Kf+FzeAXSy1BEurSCTV2SG98XW8QZpXFoo2SvDEEEjKcM0aso8wMK7pRXK6b/4YVOSjNTauu210cDpXxJu/E/iSHxdPfT3+sJex38ssr5m85HDqSfqox249K/PK1KtgcUpV+9790f1nhK+X8ScP1MNlaSTg48m3LK2ifz69dz9Jfhd+014F+K88dlp9/JpesP9zS9WVYZn9kIYpIe+EYnAyQK+oo4mliFemz+c80yLMMmly4yk4p7PdP5rT5bnwvr/AMLfiTN47v08QeFNRvdXvJZmnvrpfKt7hwDI/lXTlYydqF1VW4EYOBsAHl01j6VedSG3ns0fpNfGcJYnKMPhKqaklvFe9GVldva936r00GweBbiKTTNfl0bXHjubiOBbldIi1GO8lEylF+3x8tJ5iBQTuJxg/Nlz7H1+pGD9rSa9GmvzPgnkGDxFZRwOOhK/SanB6a6+61p1d7Hr97+znoc/inxN4g8UeKbzw4Y9QuLy4s7Dw20s2myXEn2jL3+wxR3ASaIFlchQq4JbDDtjXtBKx8rUoKNRpSTXdbPzV7P8D1/wFpnwx8OeGtc8NeG/BviSfUprCGeHWTaC7lupHDPb7LuJpEgdSElBkMYHmJIclixylNz3BR5T1xfGAt3h0uK3n8Q+IookF3ZaOiv5T7QSZHdljiB5KiR1LDoDUDsZmvfE7Qv2Z/g9LrvjidLCd7m7u1sIpFknuZ57iSYQRgcMwDgEj5VwSTtGauEHN2RMpKOrPz18R6837SHi7xX4y+Jevf8ACG67pzxQaRo9xqH2F9HtTG00dwkJiee6YHYdkShmLFiyLtx6KXs0oxVzkfvNtmR4sh13xJ8TL3wrfo8/iS2UWuv+KNA8yCXXdOkSOVIZ7XYS10flBONwKt5isY2cceLxlDL8NLF15KMIq+rS/FtL0uy4U5VZqC3PoL4c/CiP4g+IdJ+HGbi0svs66jr3kx6harBbJtVFhiudkY8x0SMYhJCKxJJXJ/D+HaVXiPOKmeV/gg2o2dF69IuVPnk+VO+tTe2h9DXaw9JUY7/P9bfkfoFb28VpBHBBGkMMShEjjUKqKBgAAdAB2r9pPHJKACgDgfjf8KLX4y/D2+8Py3Uun3wzcaffwOUa2uQrKj8dVIdkYd0dgMHBHPiMPSxVJ0a0VKL6Py1X3PUuMnB3R8BeP/AknxHGuaHrujjTfGFrdJFqmmRosZNxLM8dq8UjDlIraHcjA7WWQqThsj8UwOMxHAGO+q4luWEknZ7vlhBOUrfzSqTs113PVq04Y6ndfF/n/wAA8e8LeMviXB8QfDvgvUPGZ0zQNcFtpNnqktrH9nt7Mp5AktBIg8h/KdlJTYxLneckmv6Dp1KNen7Wk1Ja7d1v+J821OEuSRb8S/Bm91PxNBLp2mH4e67q1yYtF8MXkXkC00e0iYTX+osRuXPlAliCXZZmxjbmK1OliKbp1VzL9fI9PLsxxeU4hYnBzcJL7muzXVepxmt3Vz4R1WPSfE9vFZXUkSXEFxBMlxaXUTZ2TRSoSrIcHBBI4IzkED5DEZNWov2mGfMvua/r+kf0BlPiDluZU/qubwVOT0d1eD/O3zul3O6sPiD408T2NroFr4k1rWbaeWJbawa8kuld1YGNURiwIyBhRx2xjivOWMxkJKm279mtf8z6Gtwrw1iaMsXGnFQab5oyaivNWfLp6WP0v+DPwyv9K0LRdR8WWlnb61bRGSHS7Nnkt7GZ8mWXc5ZpJ3Lvuck7QxVScu8n10FKSUpqz7H8z4l0qM50sNLmje3Na3MumnReX39ltfEX4ZN4pM97pU1vbalNEsNzDdq5trxVO6MvsKukkbfMkqEMvvxjQ4EzD0/4NeBfhj4WU6lqt5p9jABJd3lzr1zZW8r7QCzqsyxhcKAExtCqFAwAKajfRA5dWeKfEr9u/wAF/Drw3qOm/CDwxL40k0xS01xpNi8WkWGc5eSRVG71+UYbn5xXTCg38WhhKqump896n4R+J3iPXW+MHjEW/wARNT0e2tfEVhaWk6XOlS6YysZYUjUbreaMMsiFlwxjkPzsvPQnBLkjoZWl8T1PO/Heq6Hf+LLPXfhf4m1CHXjELqHVrOSS1m0y1ZWNzLql0QZJrp3kdTsO3aFCbt6xgclTg5Vdl/WgkuZ2hueq+AvA1z4PsrSzsbN9e8U6zcSfYYbspcPqd7iRjO80Wopt3ISWLqREuRksztJ/P+b5hiuNMyWXYBtYeHxNPldu7jUoS1X2Upa7+n0dClHB0+efxP8Aroz7y+BPwZtvg34XubV7mPU9c1K4a81PUVhCebIfuxrnLeWg+VAzHGSeM4r9hwWDpYDDww1Fe7FW835vzfU8ypN1JOTPSa7jMKACgAoA8r+N/wACrT4qW9pq2mzw6H430sf8S3WzDvwvOYJlBBeJgzDGcqWLLzkN5WZ5Zhs3ws8Ji43jL7110fTVG1KrKlLmifDnxB8AR3EWs+HfG2gf2F4htrSS/OmTujC8t7XTbRUkt513DBa2uArp8ybiHUgsjfk1GpnHBWMp03+9w1SUY31snUr1G35StOF+jtbpp6Uo0sbDtJfol/keaaXoviX9nzxb4hdYtQ16PUoG0t77Tb4wa3ZpDMrObR2VhKgMSbyqEGPbvEIfB/Xsm4hy/iHDwrYSerUW4vdcyuk19+2l07N2PErYaphpNSV13KeseL4/jB4e+J/iLR47Q69fJZ6Pp2hXl3bpdWOkQjz7iWFDsVi7xJlYVyvmTHAByfpEuRxT2OVvmTZQ+F/wTs9a0/wUkWqXOheItQ0XWvE9xfx6gLMW9vCGisN0jfLEpngkLOedsg5GAaU2m22r2t/wTSnOpCLhGTSlvro/UZ8Tfjf8Ufg94tvfB2mfFrxbqU2kj7DfzXM8kcYuEJDrBvZmMQ4CudpYc4AxVRpwmruJm5yi7XPTvDGr/GjxnYXtlafG7XI9V/4RWw8Q2FvPKYVunuZVi+y+bvyrb3VFc/eZlB2is2qcfs9SryfUxdY8Dx/2z40h1/Q/EHxb8R6FrGlRCy13UbyS7/s69ty5aNInVvOV9i5OVHmLleOaT0VnZCtvfUjtvGHhH4V+JNM8PWvjy58P2/w78VagZrWG3luE8Q2bTgj/AFQ8tpyiGBxLtQrtw2ARRaUle26+4LpaX2OO8M6X458XWNhCn2rwX4a0+5uXs7+Fmhvbayu23fZjIXRVt8qxDSlEJaTazE7T5GZ5xgcpjzYid5NaRWspW/litW/RM2pUKlb4VZdz3H4afDaPwlLpmieGdDudW8TTeVcQafZO8b24YeU11LewPNA8fzMd8qrwWCKu7bX4lisZmvHdaWGorkwqdm2uZO2q5oTjTqKXo2k9+571OnSwMbvWX9eqPtT4CfAwfDCzutZ16W21bx5qa+XqGqwooRIVcmO3gxHHtjHDH5dzNksThQv6zlWV4bJ8LHC4WNorzbu++rb+V7LoebVqyqy5pHrlewYhQAUAFABQAUAc38QPh5oHxQ8M3Gg+JNPj1DT5juCtw8TgEB0YcqwBIyOoJByCQYlCM1yyV0NNp3R8tfEP9mPx54fF+NHdPiNpF1HdRRi6eG31S1M0cYUnfshmCSWls+/cjk7vlPWvy7G8DUqdWGJyefspRcHy3dvdlNuz3V41Jx6rbZI9KGMunGqr7/1+B89eLPhx4K+Iuv3dmbRLXXnu5YE0rVY3sr5JDbiWOPcdrnEiz225/NUMIcA5Iby6HE3EnDcIwzii6lOMY3nvopuEndXu+VwqWdnbn7aVPCYbEu9N2b/y/pfccbc/s5a1AbmHQfEOrJaalaQaZDE3l3PnWc6i5hV2dofKid4ioCq372NkxkqX+rw3iNlM0/rcZU5R5ubS6ThLlmrq9+W6k9PgkpbXtxSyyqvgd/6/r5nJeMfgl468dalFresazpt5ezWdknnm1ulkkjIFvbNJstyCzeWELE53Lhzv4r6aPF+RpuP1hKzkuu8FeS+Sd9N46q61OV4HEPWxsn4c/E25s5IE1vTVj/sF9AeKKwvBJJZWk6yNGA1tkyJKq5xhxt5wvNKfF2RQeuJjvH099Xi77Wktns9k7jWCxD6f0jo/+FPeNPEHiLUtd8QeNtan1G9t7aHV7uKdbNJ7LyVEcrzwtMZYPkjTzfJZAVJcjaTXz2J8QsnopRoRlUbukkrNyT1h7zjaa35JWk1blTur9MctrSd5St/X5eZt+FvhV4N8A6xY26YbxEZIEitLWM3V8ZiTtPlq5kkRjjbPZyx4OA0Yw4r5WpxZxBnydPKaHLF395dV5TlG0JrrTqU9V8MtUdkcHh6GtR3f9dO3mmfQvwv/AGc/Gnie5gln0/8A4Vf4fWKGVLpZFl1uZSwYwpJH5bIm3dn7Wsrhm5UnO3rwfBH1mbr55WdZvVx+w79XGTmoy86bgu2gTxnKrUVb+vl+J9R/Dj4VeGfhTo7WHh7TY7Z5sNeX8gD3d9JlmMlxMfmkbc7nJOBuIUAYA/UqNGnh6caVKKjGKsktkl0PNlJyd2ddWxIUAFABQB5V/wANY/BD/osnw/8A/Cosf/jtAB/w1j8EP+iyfD//AMKix/8AjtAB/wANY/BD/osnw/8A/Cosf/jtAB/w1j8EP+iyfD//AMKix/8AjtAB/wANY/BD/osnw/8A/Cosf/jtAGD4u+On7Nnj6yW08SfEf4X65AquqLf6/p8pj3ABihMmUJwOVIPA9KTSasxp22PJda0L9lG8sorbRfjdoPhCJMAro3xAtipAkWRQEuJZUTa67gUVSGYtndyPExGR5Zi5c9bDxb72V9Vyu73d46O+60ehtGvUjopFDWrL4G3LN/Zv7UPhi2R1ufNjv9b0W6WQzlfNUgbP3b4LMnQvtfIYHd4EuCckduSk425bWlK6cPga13ivdT35fd20N1jKvV/09yzDbfARjMbv9qPSJWf7O6zQ+J9EjlEsK7VmLlCTKR8pkGGKgKxYCiHBGRQf8DT3tOaVrS1cbXtyX1UdovWKTB4yt3Lmn6X+ynE8R1X42+H/ABCkTzSpDf8Aj21iiR5Tl2WO3liVc85AAU7iSCea9zD5BleFbdLDxu0k21dtR+G7d27dL3sYyxFWW8j1Hwb8bf2aPh5ZNa+GPiJ8LdBhdESQWGvadE0oQELvYSZcjc3LEn5ie5r3zC9zof8AhrH4If8ARZPh/wD+FRY//HaBB/w1j8EP+iyfD/8A8Kix/wDjtAB/w1j8EP8Aosnw/wD/AAqLH/47QAf8NY/BD/osnw//APCosf8A47QAf8NY/BD/AKLJ8P8A/wAKix/+O0AH/DWPwQ/6LJ8P/wDwqLH/AOO0AfzWUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFAH/9k=', 'E-Survey', 'Kucip', 'E-Survey Bakamla Kupang', NULL, NULL, NULL, NULL, 1, NULL, '2024-07-04 00:57:34');

-- --------------------------------------------------------

--
-- Table structure for table `mskerja`
--

CREATE TABLE `mskerja` (
  `kerjaId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `kerjaNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mskerja`
--

INSERT INTO `mskerja` (`kerjaId`, `compId`, `kerjaNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'ASN', '2024-06-21 18:59:05', '2024-06-21 18:59:05'),
(2, 1, 'TNI', '2024-06-21 18:59:09', '2024-06-21 18:59:09'),
(3, 1, 'POLRI', '2024-06-21 18:59:13', '2024-06-21 18:59:13'),
(4, 1, 'Petani', '2024-06-21 18:59:24', '2024-06-21 18:59:24'),
(5, 1, 'Nelayan', '2024-06-21 18:59:29', '2024-06-21 18:59:29'),
(7, 1, 'Swasta', '2024-06-21 18:59:46', '2024-06-21 19:00:17'),
(8, 1, 'Lainnya', '2024-06-21 19:00:23', '2024-06-21 19:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `mslayanan`
--

CREATE TABLE `mslayanan` (
  `layId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `layNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mslayanan`
--

INSERT INTO `mslayanan` (`layId`, `compId`, `layNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'Perbantuan Keselamatan Laut', '2024-06-04 19:10:58', '2024-06-13 11:51:05'),
(2, 1, 'Data dan Informasi (IMIC)', '2024-06-04 19:11:46', '2024-06-13 11:51:16'),
(3, 1, 'Relawan Penjaga Laut Nusantara', '2024-06-04 19:11:52', '2024-06-13 11:51:30');

-- --------------------------------------------------------

--
-- Table structure for table `mssekolah`
--

CREATE TABLE `mssekolah` (
  `sekId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `sekLevel` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mssekolah`
--

INSERT INTO `mssekolah` (`sekId`, `compId`, `sekLevel`, `created_at`, `updated_at`) VALUES
(1, 1, 'SD/MI', '2024-05-30 08:31:04', '2024-05-30 08:45:48'),
(2, 1, 'SMP/MTS', '2024-05-30 08:31:09', '2024-05-30 08:45:57'),
(3, 1, 'SMA/SMK/MA', '2024-05-30 08:31:14', '2024-05-30 08:46:09'),
(4, 1, 'DIPLOMA (D1,D2,D3,D4)', '2024-05-30 08:31:28', '2024-05-30 08:46:34'),
(5, 1, 'S1 (Sarjana)', '2024-05-30 08:31:44', '2024-05-30 08:31:44'),
(6, 1, 'S2 (Magister)', '2024-05-30 08:31:53', '2024-05-30 08:31:53'),
(7, 1, 'S3 (Doktor)', '2024-05-30 08:32:04', '2024-05-30 08:32:04');

-- --------------------------------------------------------

--
-- Table structure for table `mssurvey`
--

CREATE TABLE `mssurvey` (
  `surId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `surPertanyaan` text NOT NULL,
  `surOpt1` text NOT NULL,
  `surOpt2` text NOT NULL,
  `surOpt3` text NOT NULL,
  `surOpt4` text NOT NULL,
  `surOpt5` text NOT NULL,
  `surUnsur` varchar(200) NOT NULL,
  `surBobot1` int(11) NOT NULL DEFAULT 1,
  `surBobot2` int(11) NOT NULL DEFAULT 1,
  `surBobot3` int(11) NOT NULL DEFAULT 1,
  `surBobot4` int(11) NOT NULL DEFAULT 1,
  `surBobot5` int(11) NOT NULL DEFAULT 1,
  `surTayang` int(10) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mssurvey`
--

INSERT INTO `mssurvey` (`surId`, `compId`, `surPertanyaan`, `surOpt1`, `surOpt2`, `surOpt3`, `surOpt4`, `surOpt5`, `surUnsur`, `surBobot1`, `surBobot2`, `surBobot3`, `surBobot4`, `surBobot5`, `surTayang`, `created_at`, `updated_at`) VALUES
(2, 1, 'Bagaimana kecakapan dan kemampuan personel Bakamla RI dalam memberikan layanan kepada saudara?', 'Tidak terlatih', 'Kurang terlatih', 'Cukup', 'Terlatih', 'Sangat terlatih', 'Kompetensi Pelaksana', 1, 1, 1, 1, 1, 1, '2024-05-28 10:21:07', '2024-07-09 13:18:58'),
(5, 1, 'Bagaimana pendapat saudara tentang kewajaran biaya/tarif dari layanan yang diterima?', 'Mahal', 'Murah', 'Cukup', 'Sangat murah', 'Gratis', 'Tarif/Biaya', 1, 1, 1, 1, 1, 1, '2024-05-28 10:31:18', '2024-07-01 08:36:41'),
(6, 1, 'Apakah layanan yang diberikan oleh petugas Bakamla RI sudah sesuai dengan yang saudara harapkan?', 'Tidak sesuai', 'Kurang sesuai', 'Cukup', 'Sesuai', 'Sangat sesuai', 'Produk Spesifikasi Jenis Pelayanan', 1, 1, 1, 1, 1, 1, '2024-05-28 10:32:13', '2024-07-09 13:18:34'),
(7, 1, 'Bagaimana pendapat saudara terhadap kualitas sarana dan prasarana yang dimiliki oleh Bakamla RI?', 'Tidak baik', 'Kurang baik', 'Cukup', 'Baik', 'Sangat baik', 'Sarana dan Prasarana', 1, 1, 1, 1, 1, 1, '2024-05-28 10:32:59', '2024-07-01 08:36:23'),
(8, 1, 'Bagaimana penanganan petugas Bakamla dalam menerima pengaduan, saran dan masukan dari saudara?', 'Tidak baik', 'Kurang baik', 'Cukup', 'Baik', 'Sangat baik', 'Penanganan Pengaduan, Saran dan Masukan', 1, 1, 1, 1, 1, 1, '2024-05-28 10:33:58', '2024-07-09 13:18:01'),
(9, 1, 'Bagaimana perilaku petugas Bakamla dalam memberikan pelayanan kepada saudara?', 'Tidak baik', 'Kurang baik', 'Cukup', 'Baik', 'Sangat baik', 'Perilaku', 1, 1, 1, 1, 1, 1, '2024-05-28 10:34:43', '2024-07-01 08:35:52'),
(10, 1, 'Bagaimana kecepatan respon dari petugas Bakamla RI yang menerima pengaduan saudara?', 'Tidak responsif', 'Kurang responsif', 'Cukup responsif', 'Responsif', 'Sangat responsif', 'Waktu Penyelesaian', 1, 1, 1, 1, 1, 1, '2024-05-28 10:35:38', '2024-07-09 13:16:37'),
(11, 1, 'Bagaimana pendapat saudara tentang Persyaratan layanan publik di Bakamla RI?', 'Tidak mudah', 'Kurang mudah', 'Cukup mudah', 'Mudah', 'Sangat mudah', 'Persyaratan', 1, 1, 1, 1, 1, 1, '2024-05-28 10:36:28', '2024-07-01 08:35:35'),
(12, 1, 'Bagaimana pendapat saudara tentang kemudahan prosedur yang diminta oleh petugas/pegawai Bakamla RI dalam memberikan layanan?', 'Tidak mudah', 'Kurang mudah', 'Cukup mudah', 'Mudah', 'Sangat mudah', 'Prosedur', 1, 1, 1, 1, 1, 1, '2024-06-13 11:56:41', '2024-07-01 08:35:21');

-- --------------------------------------------------------

--
-- Table structure for table `msumur`
--

CREATE TABLE `msumur` (
  `umurId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `umurNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msumur`
--

INSERT INTO `msumur` (`umurId`, `compId`, `umurNama`, `created_at`, `updated_at`) VALUES
(5, 1, '<= 20 Tahun', '2024-05-30 08:40:29', '2024-06-20 08:26:24'),
(6, 1, '21-30 Tahun', '2024-05-30 08:40:36', '2024-06-20 08:25:46'),
(7, 1, '31-40 Tahun', '2024-05-30 08:40:50', '2024-06-20 08:25:33'),
(8, 1, '41-50 Tahun', '2024-05-30 08:40:59', '2024-06-20 08:27:47'),
(9, 1, '51-60 Tahun', '2024-05-30 08:41:10', '2024-06-20 08:27:19'),
(10, 1, '>=61 Tahun', '2024-05-30 08:41:17', '2024-06-20 08:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `msunit`
--

CREATE TABLE `msunit` (
  `unitId` int(11) NOT NULL,
  `compId` int(11) NOT NULL,
  `unitNama` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msunit`
--

INSERT INTO `msunit` (`unitId`, `compId`, `unitNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'SPKKL Kupang', '2024-06-04 19:03:56', '2024-06-13 11:49:45'),
(2, 1, 'SPKKL Ambon', '2024-06-04 19:04:01', '2024-06-13 11:49:56'),
(3, 1, 'SPKKL Tual', '2024-06-04 19:04:06', '2024-06-13 11:50:05'),
(4, 1, 'SPKKL Jayapura', '2024-06-13 11:50:14', '2024-06-13 11:50:14'),
(5, 1, 'SPKKL Merauke', '2024-06-13 11:50:21', '2024-06-13 11:50:21');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(106, 'App\\Models\\User', 7, 'auth_token', '6acf9e34e057f572e97a1e98ad3ac2c7c81833afc90b91a7b123d81bf96beb8d', '[\"*\"]', NULL, '2024-07-01 06:26:17', '2024-07-01 06:26:17'),
(107, 'App\\Models\\User', 7, 'auth_token', '821a7b066310582a6bcec279c7904a4e012ced2afc64e61f3c68c8ed04672970', '[\"*\"]', NULL, '2024-07-01 06:26:57', '2024-07-01 06:26:57'),
(133, 'App\\Models\\User', 1, 'auth_token', '7cbe97d5ee8a19e0e1515c340532d06aca2563acfcf7a1fc0b9c95e30cdd7657', '[\"*\"]', NULL, '2024-07-09 06:06:06', '2024-07-09 06:06:06'),
(134, 'App\\Models\\User', 1, 'auth_token', '200c9f86fbf02defcf2e7880e2a6bcfff4da9c439e90d995c84ed7953d315549', '[\"*\"]', NULL, '2024-07-09 06:12:59', '2024-07-09 06:12:59'),
(135, 'App\\Models\\User', 1, 'auth_token', 'f6341acfd20be6d1bbf167706a67604fde6e9fb9884a2b34049ec9ed4338f28c', '[\"*\"]', NULL, '2024-07-10 01:18:36', '2024-07-10 01:18:36'),
(136, 'App\\Models\\User', 1, 'auth_token', '9babfc7b26475fdcf8adda3f07bb8b0aa072ea6e22165d5e39ce0f7ba3cceab8', '[\"*\"]', NULL, '2024-07-10 07:26:04', '2024-07-10 07:26:04'),
(137, 'App\\Models\\User', 1, 'auth_token', '81c19a8c80c5393e9eb50fb43b2b6b2f89b938722ce2cf68729261ff9da3ce4f', '[\"*\"]', NULL, '2024-07-11 00:39:14', '2024-07-11 00:39:14'),
(138, 'App\\Models\\User', 1, 'auth_token', '02a9dec248e4fc0fc90329cf49fad1f78fd1024d3afa66f3bcfb4d1eec1ad1af', '[\"*\"]', NULL, '2024-07-11 03:34:24', '2024-07-11 03:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `roleId` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `roleNama` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleId`, `compId`, `roleNama`, `created_at`, `updated_at`) VALUES
(1, 1, 'Administrator Utama', NULL, NULL),
(2, 1, 'Administrator Umum', '2024-07-09 03:38:17', '2024-07-09 03:38:17');

-- --------------------------------------------------------

--
-- Table structure for table `role_menu`
--

CREATE TABLE `role_menu` (
  `rmId` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `rmRoleId` int(11) NOT NULL,
  `rmMenuId` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role_menu`
--

INSERT INTO `role_menu` (`rmId`, `compId`, `rmRoleId`, `rmMenuId`, `created_at`, `updated_at`) VALUES
(239, 1, 1, 1, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(240, 1, 1, 2, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(241, 1, 1, 3, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(242, 1, 1, 4, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(243, 1, 1, 5, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(244, 1, 1, 6, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(245, 1, 1, 7, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(246, 1, 1, 8, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(247, 1, 1, 9, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(248, 1, 1, 10, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(249, 1, 1, 12, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(250, 1, 1, 13, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(251, 1, 1, 14, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(252, 1, 1, 15, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(253, 1, 1, 16, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(254, 1, 1, 17, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(255, 1, 1, 18, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(256, 1, 1, 19, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(257, 1, 1, 20, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(258, 1, 1, 21, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(259, 1, 1, 22, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(260, 1, 1, 23, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(261, 1, 1, 24, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(262, 1, 1, 25, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(263, 1, 1, 26, '2024-06-28 12:48:23', '2024-06-28 12:48:23'),
(271, 1, 2, 18, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(272, 1, 2, 19, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(273, 1, 2, 20, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(274, 1, 2, 21, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(275, 1, 2, 22, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(276, 1, 2, 23, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(277, 1, 2, 24, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(278, 1, 2, 25, '2024-07-09 03:43:24', '2024-07-09 03:43:24'),
(279, 1, 2, 26, '2024-07-09 03:43:24', '2024-07-09 03:43:24');

-- --------------------------------------------------------

--
-- Table structure for table `syslog`
--

CREATE TABLE `syslog` (
  `id` int(10) UNSIGNED NOT NULL,
  `compId` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `tabel` varchar(255) NOT NULL,
  `query` varchar(255) NOT NULL,
  `detail` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `compId` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `compId`, `role`, `created_at`, `updated_at`) VALUES
(1, 'SPKKL Kupang', 'bakamla', 'admin@gmail.com', '2023-06-21 14:02:55', '$2y$10$hRhCfSDuA4CgmGUj5OD.8.LnSl6YtRFUFwPFbd/yJCwljQvEdVTa2', '', 1, 1, NULL, '2024-07-01 06:07:48'),
(7, 'Yeanry Olang', 'dejavu', 'yeanry.bakamla@gmail.com', NULL, '$2y$10$W5w0tYT1oXEnAr6IEo5Wz.6AOynOji7mG4IqTHmGUe5iKUleE1LvC', NULL, 1, 1, '2024-07-01 06:26:17', '2024-07-01 06:26:17'),
(8, 'admin', 'zonatimur@gmail.com', 'zonatimur@gmail.com', NULL, '$2y$10$gKAU2jfAjNrDpBKZ5pql1OVAcu.dYH3e9SQW4JWpjAy50h4Xk.Pra', NULL, 1, 2, '2024-07-09 03:41:32', '2024-07-09 03:41:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `datasurvey`
--
ALTER TABLE `datasurvey`
  ADD PRIMARY KEY (`dataId`);

--
-- Indexes for table `docs`
--
ALTER TABLE `docs`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menuId`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `msagama`
--
ALTER TABLE `msagama`
  ADD PRIMARY KEY (`agamaId`);

--
-- Indexes for table `mscompany`
--
ALTER TABLE `mscompany`
  ADD PRIMARY KEY (`compId`);

--
-- Indexes for table `mskerja`
--
ALTER TABLE `mskerja`
  ADD PRIMARY KEY (`kerjaId`);

--
-- Indexes for table `mslayanan`
--
ALTER TABLE `mslayanan`
  ADD PRIMARY KEY (`layId`);

--
-- Indexes for table `mssekolah`
--
ALTER TABLE `mssekolah`
  ADD PRIMARY KEY (`sekId`);

--
-- Indexes for table `mssurvey`
--
ALTER TABLE `mssurvey`
  ADD PRIMARY KEY (`surId`);

--
-- Indexes for table `msumur`
--
ALTER TABLE `msumur`
  ADD PRIMARY KEY (`umurId`);

--
-- Indexes for table `msunit`
--
ALTER TABLE `msunit`
  ADD PRIMARY KEY (`unitId`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `role_menu`
--
ALTER TABLE `role_menu`
  ADD PRIMARY KEY (`rmId`);

--
-- Indexes for table `syslog`
--
ALTER TABLE `syslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datasurvey`
--
ALTER TABLE `datasurvey`
  MODIFY `dataId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `docs`
--
ALTER TABLE `docs`
  MODIFY `did` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menuId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `msagama`
--
ALTER TABLE `msagama`
  MODIFY `agamaId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mscompany`
--
ALTER TABLE `mscompany`
  MODIFY `compId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mskerja`
--
ALTER TABLE `mskerja`
  MODIFY `kerjaId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mslayanan`
--
ALTER TABLE `mslayanan`
  MODIFY `layId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mssekolah`
--
ALTER TABLE `mssekolah`
  MODIFY `sekId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mssurvey`
--
ALTER TABLE `mssurvey`
  MODIFY `surId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `msumur`
--
ALTER TABLE `msumur`
  MODIFY `umurId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `msunit`
--
ALTER TABLE `msunit`
  MODIFY `unitId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `roleId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role_menu`
--
ALTER TABLE `role_menu`
  MODIFY `rmId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=280;

--
-- AUTO_INCREMENT for table `syslog`
--
ALTER TABLE `syslog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
